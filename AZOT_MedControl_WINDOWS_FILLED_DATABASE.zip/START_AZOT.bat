@echo off
setlocal EnableExtensions DisableDelayedExpansion
if not exist "%~dp0AZOT_MedControl_Windows\start.bat" goto missing
call "%~dp0AZOT_MedControl_Windows\start.bat"
exit /b %errorlevel%
:missing
echo ERROR: Please extract the whole ZIP before running this BAT.
echo The AZOT_MedControl_Windows folder must be alongside START_AZOT.bat.
pause
exit /b 1
