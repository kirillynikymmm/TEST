"""Regression checks for the one-click Windows packaging improvements.

Note: static CMD checks are NOT a substitute for running BAT in actual Windows.
"""
from __future__ import annotations

import os
import sqlite3
import tempfile
import unittest
from pathlib import Path
from unittest import mock

import launcher
from database import Store

ROOT = Path(__file__).resolve().parent
RELEASE = ROOT.parent


class BatchPackagingTests(unittest.TestCase):
    def test_one_click_entry_and_diagnostic_are_in_root(self):
        for name in ('START_AZOT.bat', 'CHECK_AZOT.bat'):
            data = (RELEASE / name).read_bytes()
            self.assertTrue(data.startswith(b'@echo off\r\n'))
            self.assertNotIn(b'\xef\xbb\xbf', data)
            self.assertIn(b'%~dp0AZOT_MedControl_Windows\\', data)

    def test_start_has_all_labels_and_works_with_shortcuts(self):
        content = (ROOT / 'start.bat').read_bytes()
        self.assertIn(b'pushd "%~dp0"', content)
        self.assertIn(b'setlocal EnableExtensions DisableDelayedExpansion', content)
        self.assertIn(b'"%AZOT_EXE%" %AZOT_ARGS% -u "%APP_TARGET%"', content)
        self.assertIn(b'tkinter as t', content)
        for label in [b':find_python', b':probe', b':probe_on_path', b':launch', b':missing_python',
                      b':missing_files', b':write_no_python_report']:
            self.assertIn(b'\r\n' + label + b'\r\n', content)
        self.assertNotIn(b'\n', content.replace(b'\r\n', b''))

    def test_install_requires_confirmation(self):
        content = (ROOT / 'start.bat').read_text(encoding='ascii')
        self.assertIn('choice /C YN', content)
        self.assertIn('WindowsApps', content)
        self.assertIn('if errorlevel 2 goto missing_python', content)
        installer = (ROOT / 'INSTALL_PYTHON.bat').read_text(encoding='ascii')
        self.assertIn('winget install --id Python.Python.3.13', installer)
        self.assertIn('--scope user', installer)

    def test_diagnose_does_not_require_tk_probe_before_running(self):
        content = (ROOT / 'start.bat').read_text(encoding='ascii')
        self.assertIn('if defined CHECK_MODE set "APP_TARGET=diagnose.py"', content)
        self.assertIn('if not defined CHECK_MODE set "PROBE=', content)
        self.assertIn('set "PROBE=import sys, sqlite3;', content)


class ErrorRecoveryTests(unittest.TestCase):
    def test_database_backup_succeeds_even_if_optional_audit_fails(self):
        with tempfile.TemporaryDirectory() as td:
            home = Path(td)
            store = Store(home / 'source.sqlite3')
            with mock.patch.object(store, 'audit_event', side_effect=sqlite3.OperationalError('locked')):
                store.backup(home / 'copy.sqlite3')
            with sqlite3.connect(home / 'copy.sqlite3') as db:
                self.assertEqual(db.execute('PRAGMA quick_check').fetchone()[0], 'ok')
                self.assertEqual(db.execute('SELECT count(*) FROM sqlite_master WHERE name="employees"').fetchone()[0], 1)

    def test_startup_error_logs_to_user_profile_if_program_unwritable(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            fake_program = root / 'blocked'
            fake_program.write_text('not a folder')
            profile = root / 'profile'
            try:
                raise RuntimeError('test crash for Windows user data fallback')
            except RuntimeError:
                with mock.patch.object(launcher, 'ROOT', fake_program), \
                     mock.patch.dict(os.environ, {'LOCALAPPDATA': str(profile)}):
                    path = launcher.log_startup_error()
            self.assertIsNotNone(path)
            self.assertEqual(path, profile / 'AZOT_MedControl' / 'logs' / 'startup_errors.log')
            self.assertIn('test crash for Windows', path.read_text(encoding='utf-8'))


if __name__ == '__main__':
    unittest.main()
