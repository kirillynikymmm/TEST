"""КАО Азот: демонстрационная модель хранения предсменных и предрейсовых осмотров.

Только стандартная библиотека Python: tkinter + sqlite3.
НЕ является медицинской информационной системой для юридически значимых осмотров.
"""

from __future__ import annotations

from contextlib import contextmanager
import json
import math
import os
import tempfile
import sqlite3
from datetime import date, datetime, timedelta
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
DB_PATH = DATA_DIR / "medcontrol.sqlite3"
EXPORTS_DIR = BASE_DIR / "exports"
BACKUPS_DIR = BASE_DIR / "backups"

EXAM_TYPES = ("Предсменный", "Предрейсовый")
CONCLUSIONS = ("Допущен", "Не допущен")
ALCOHOL_RESULTS = ("Не выбран", "Отрицательный", "Положительный")
DRUG_RESULTS = ("Не требовалось", "Ожидается / не проведено", "Отрицательный", "Положительный")
SIGNS_OPTIONS = ("Не оценено", "Не выявлены", "Выявлены")
SYMPTOM_OPTIONS = ("Головная боль", "Головокружение", "Слабость", "Тошнота", "Кашель")


def user_profile_db_path() -> Path:
    """Per-user fallback for installations in Windows-protected folders."""
    profile = os.environ.get("LOCALAPPDATA")
    if profile:
        return Path(profile) / "AZOT_MedControl" / "data" / "medcontrol.sqlite3"
    return Path.home() / ".local" / "share" / "AZOT_MedControl" / "medcontrol.sqlite3"


def verify_folder_writable(folder: Path) -> None:
    """Test real filesystem permissions, not os.access (which can lie on Windows)."""
    folder.mkdir(parents=True, exist_ok=True)
    fd, test_file = tempfile.mkstemp(prefix=".azot_check_", dir=folder)
    os.close(fd)
    Path(test_file).unlink()


def resolve_default_db_path() -> Path:
    """Prefer existing data; don't silently hide a read-only existing database.

    On a new installation, if the app directory can't be written (e.g.
    Program Files), store the database in the user's LocalAppData instead.
    Reuse that fallback across version updates so existing records are visible.
    """
    local = DB_PATH
    fallback = user_profile_db_path()
    for candidate in (local, fallback):
        if candidate.exists():
            if not candidate.is_file():
                raise PermissionError(f"Путь к базе данных занят папкой: {candidate}")
            try:
                verify_folder_writable(candidate.parent)
                # A writable directory alone doesn't imply the database file
                # has the rights needed for updates. This makes no changes.
                with candidate.open("r+b"):
                    pass
            except OSError as exc:
                raise PermissionError(
                    f"Существующая база недоступна для записи: {candidate}. "
                    "Не создаём вместо неё пустую базу. Перенесите папку программы "
                    "в доступное для записи место или обратитесь к администратору."
                ) from exc
            return candidate
    try:
        verify_folder_writable(local.parent)
        return local
    except OSError:
        try:
            verify_folder_writable(fallback.parent)
            return fallback
        except OSError as exc:
            raise PermissionError(
                "Нельзя создать базу ни рядом с программой, ни в профиле пользователя. "
                "Проверьте права на папки и доступное место на диске."
            ) from exc


def now_iso() -> str:
    return datetime.now().astimezone().isoformat(timespec="seconds")


def display_datetime(value: str | None) -> str:
    if not value:
        return "—"
    try:
        return datetime.fromisoformat(value).strftime("%d.%m.%Y %H:%M:%S")
    except ValueError:
        return value


def display_date(value: str | None) -> str:
    if not value:
        return "—"
    try:
        return date.fromisoformat(value).strftime("%d.%m.%Y")
    except ValueError:
        return value


def parse_float(value: str, name: str, minimum: float, maximum: float) -> float:
    try:
        number = float(value.strip().replace(",", "."))
    except (ValueError, AttributeError):
        raise ValueError(f"Поле «{name}»: введите число.") from None
    if not math.isfinite(number) or not minimum <= number <= maximum:
        raise ValueError(f"Поле «{name}»: проверьте значение ({minimum:g}–{maximum:g}).")
    return number


def parse_int(value: str, name: str, minimum: int, maximum: int) -> int:
    raw = value.strip() if isinstance(value, str) else ""
    # isdigit() accepts Unicode superscript digits that int() cannot parse.
    # Length-check also protects against impractically long pasted values.
    if not raw or len(raw) > 9 or not all("0" <= c <= "9" for c in raw):
        raise ValueError(f"Поле «{name}»: введите целое число.")
    number = int(raw)
    if not minimum <= number <= maximum:
        raise ValueError(f"Поле «{name}»: проверьте значение ({minimum}–{maximum}).")
    return number


def format_number(value: float | None) -> str:
    """Keep the journal usable even with a malformed old numeric cell."""
    if value is None:
        return "—"
    try:
        number = float(str(value).replace(",", "."))
    except (TypeError, ValueError):
        return "—"
    return f"{number:g}" if math.isfinite(number) else "—"


def safe_csv_cell(value):
    """Prevent formulas embedded in free-text cells from executing in Excel."""
    if isinstance(value, str) and value.lstrip(" \t\r\n").startswith(("=", "+", "-", "@")):
        return "'" + value
    return value


class Store:
    def __init__(self, db_path: Path | None = None):
        self.db_path = Path(db_path) if db_path is not None else resolve_default_db_path()
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.initialize()

    @contextmanager
    def connect(self):
        connection = sqlite3.connect(self.db_path, timeout=10)
        try:
            connection.row_factory = sqlite3.Row
            connection.execute("PRAGMA foreign_keys=ON")
            with connection:
                yield connection
        finally:
            connection.close()

    def initialize(self) -> None:
        with self.connect() as db:
            db.executescript("""
                CREATE TABLE IF NOT EXISTS employees (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    personnel_number TEXT NOT NULL UNIQUE,
                    full_name TEXT NOT NULL,
                    birth_date TEXT NOT NULL,
                    sex TEXT NOT NULL,
                    department TEXT NOT NULL DEFAULT '',
                    position TEXT NOT NULL DEFAULT '',
                    created_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS medical_exams (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    employee_id INTEGER NOT NULL REFERENCES employees(id),
                    personnel_number TEXT NOT NULL,
                    employee_name TEXT NOT NULL,
                    employee_birth_date TEXT NOT NULL,
                    employee_sex TEXT NOT NULL,
                    employee_department TEXT NOT NULL DEFAULT '',
                    employee_position TEXT NOT NULL DEFAULT '',
                    exam_type TEXT NOT NULL,
                    shift_label TEXT NOT NULL DEFAULT '',
                    examined_at TEXT NOT NULL,
                    saved_at TEXT NOT NULL,
                    nurse_name TEXT NOT NULL,
                    complaints TEXT NOT NULL,
                    complaint_tags TEXT NOT NULL DEFAULT '[]',
                    visual_notes TEXT NOT NULL,
                    intoxication_signs INTEGER NOT NULL,
                    alcohol_level REAL NOT NULL,
                    alcohol_unit TEXT NOT NULL,
                    alcohol_result TEXT NOT NULL,
                    drug_result TEXT NOT NULL,
                    conclusion TEXT NOT NULL,
                    non_admission_reason TEXT NOT NULL,
                    medical_comment TEXT NOT NULL,
                    acknowledged_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS measurements (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    exam_id INTEGER NOT NULL REFERENCES medical_exams(id),
                    attempt_no INTEGER NOT NULL CHECK(attempt_no BETWEEN 1 AND 3),
                    measured_at TEXT NOT NULL,
                    temperature REAL,
                    systolic INTEGER NOT NULL,
                    diastolic INTEGER NOT NULL,
                    pulse INTEGER NOT NULL,
                    UNIQUE(exam_id, attempt_no)
                );
                CREATE TABLE IF NOT EXISTS audit_events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    exam_id INTEGER REFERENCES medical_exams(id),
                    event_type TEXT NOT NULL,
                    description TEXT NOT NULL,
                    created_at TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_exams_examined_at ON medical_exams(examined_at);
                CREATE INDEX IF NOT EXISTS idx_exams_employee ON medical_exams(employee_id);
            """)
            # Бесшовное обновление схемы из версии 2 без удаления старых записей.
            upgrades = {
                "employees": {
                    "department": "TEXT NOT NULL DEFAULT ''",
                    "position": "TEXT NOT NULL DEFAULT ''",
                },
                "medical_exams": {
                    "employee_department": "TEXT NOT NULL DEFAULT ''",
                    "employee_position": "TEXT NOT NULL DEFAULT ''",
                    "shift_label": "TEXT NOT NULL DEFAULT ''",
                    "complaint_tags": "TEXT NOT NULL DEFAULT '[]'",
                },
            }
            for table, columns in upgrades.items():
                present = {r["name"] for r in db.execute(f"PRAGMA table_info({table})")}
                for column, column_type in columns.items():
                    if column not in present:
                        db.execute(f"ALTER TABLE {table} ADD COLUMN {column} {column_type}")

    def list_employees(self) -> list[sqlite3.Row]:
        with self.connect() as db:
            return db.execute("SELECT * FROM employees ORDER BY full_name COLLATE NOCASE").fetchall()

    def save_employee(self, personnel_number: str, full_name: str, birth_date: str, sex: str,
                      employee_id: int | None = None, department: str = "", position: str = "") -> int:
        personnel_number = personnel_number.strip()
        full_name = " ".join(full_name.split())
        department = " ".join(department.split())
        position = " ".join(position.split())
        if not personnel_number or not full_name:
            raise ValueError("Укажите табельный номер и ФИО.")
        if len(personnel_number) > 50 or len(full_name) > 180:
            raise ValueError("Табельный номер (до 50) или ФИО (до 180 символов) слишком длинные.")
        if len(department) > 120 or len(position) > 120:
            raise ValueError("Цех и должность должны содержать не более 120 символов.")
        try:
            birth_normalized = datetime.strptime(birth_date.strip(), "%d.%m.%Y").date()
        except ValueError:
            raise ValueError("Дата рождения должна иметь формат ДД.ММ.ГГГГ.") from None
        if birth_normalized > date.today():
            raise ValueError("Дата рождения не может быть в будущем.")
        if sex not in ("М", "Ж"):
            raise ValueError("Выберите пол сотрудника.")
        try:
            with self.connect() as db:
                if employee_id is None:
                    cursor = db.execute("""
                        INSERT INTO employees(personnel_number, full_name, birth_date, sex,
                                              department, position, created_at)
                        VALUES(?, ?, ?, ?, ?, ?, ?)
                    """, (personnel_number, full_name, birth_normalized.isoformat(), sex,
                          department, position, now_iso()))
                    return int(cursor.lastrowid)
                cursor = db.execute("""
                    UPDATE employees SET personnel_number=?, full_name=?, birth_date=?, sex=?,
                                         department=?, position=? WHERE id=?
                """, (personnel_number, full_name, birth_normalized.isoformat(), sex,
                      department, position, employee_id))
                if cursor.rowcount == 0:
                    raise ValueError("Карточка сотрудника не найдена. Обновите список.")
                return employee_id
        except sqlite3.IntegrityError as exc:
            if "UNIQUE" in str(exc):
                raise ValueError("Такой табельный номер уже существует.") from None
            raise

    def get_employee(self, employee_id: int) -> sqlite3.Row | None:
        with self.connect() as db:
            return db.execute("SELECT * FROM employees WHERE id=?", (employee_id,)).fetchone()

    def validate_exam(self, details: dict, readings: list[dict]) -> tuple[list[str], str]:
        """Independent data validation: protects SQLite even if UI validation is bypassed.

        Clinical acceptance criteria are deliberately NOT calculated from vital signs.
        """
        if not isinstance(details, dict):
            raise ValueError("Неверный формат сведений об осмотре.")
        if not isinstance(readings, (list, tuple)):
            raise ValueError("Неверный формат измерений.")
        employee_id = details.get("employee_id")
        if type(employee_id) is not int or employee_id <= 0:
            raise ValueError("Выберите сотрудника из справочника.")
        if not 1 <= len(readings) <= 3:
            raise ValueError("Нужно первичное измерение; повторных может быть не более двух.")
        if details.get("exam_type") not in EXAM_TYPES:
            raise ValueError("Неверно указан тип осмотра.")
        nurse_value = details.get("nurse_name")
        if not isinstance(nurse_value, str):
            raise ValueError("Укажите ФИО медицинского работника текстом.")
        nurse = " ".join(nurse_value.split())
        if not nurse or len(nurse) > 180:
            raise ValueError("Укажите ФИО медицинского работника (до 180 символов).")
        if not isinstance(details.get("complaints"), str) or not isinstance(details.get("visual_notes"), str):
            raise ValueError("Жалобы и визуальный осмотр должны быть указаны текстом.")
        complaints = details["complaints"].strip()
        visual_notes = details["visual_notes"].strip()
        if not complaints or not visual_notes:
            raise ValueError("Укажите жалобы (или их отсутствие) и результат визуального осмотра.")
        if len(complaints) > 2500 or len(visual_notes) > 2500:
            raise ValueError("Описание жалоб или визуального осмотра слишком длинное.")
        tags = details.get("complaint_tags", [])
        if not isinstance(tags, (list, tuple)) or any(t not in SYMPTOM_OPTIONS for t in tags):
            raise ValueError("Некорректно указаны жалобы.")
        if tags and complaints.casefold() in ("жалоб нет", "нет жалоб"):
            raise ValueError("Отмечены жалобы, но в описании написано «Жалоб нет».")
        shift = " ".join(str(details.get("shift_label", "")).split())
        if len(shift) > 60:
            raise ValueError("Название смены должно содержать не более 60 символов.")
        if details.get("alcohol_unit") not in ("мг/л", "мкг/л"):
            raise ValueError("Укажите единицу измерения алкотеста.")
        level = details.get("alcohol_level")
        try:
            level = float(level)
        except (TypeError, ValueError):
            raise ValueError("Нужно числовое значение алкотеста.") from None
        if not math.isfinite(level) or not 0 <= level <= 1000:
            raise ValueError("Некорректное значение алкотеста.")
        if details.get("alcohol_result") not in ALCOHOL_RESULTS[1:]:
            raise ValueError("Укажите оценку результата алкотеста.")
        if details.get("drug_result") not in DRUG_RESULTS:
            raise ValueError("Некорректное значение исследования мочи.")
        signs = details.get("intoxication_signs")
        if type(signs) is not bool and signs not in (0, 1):
            raise ValueError("Нужно явно указать наличие или отсутствие признаков опьянения.")
        if bool(signs) and details["alcohol_result"] == "Отрицательный" and details["drug_result"] in DRUG_RESULTS[:2]:
            raise ValueError("При признаках опьянения и отрицательном алкотесте отметьте результат предусмотренного исследования мочи.")
        conclusion = details.get("conclusion")
        if conclusion not in CONCLUSIONS:
            raise ValueError("Не указано заключение медработника.")
        reason_value = details.get("non_admission_reason", "")
        comment_value = details.get("medical_comment", "")
        if not isinstance(reason_value, str) or not isinstance(comment_value, str):
            raise ValueError("Причина недопуска и комментарий должны быть текстом.")
        reason = reason_value.strip()
        if conclusion == "Не допущен" and not reason:
            raise ValueError("Для недопуска укажите причину.")
        if conclusion == "Допущен" and (bool(signs) or details["alcohol_result"] == "Положительный" or details["drug_result"] == "Положительный"):
            raise ValueError("Результаты исследований конфликтуют с заключением «Допущен».")
        if conclusion == "Допущен" and reason:
            raise ValueError("При допуске очистите поле причины недопуска.")
        if len(reason) > 500 or len(comment_value) > 2500:
            raise ValueError("Причина недопуска или комментарий слишком длинные.")

        previous = None
        for i, reading in enumerate(readings):
            if not isinstance(reading, dict):
                raise ValueError(f"Измерение № {i+1}: некорректные данные.")
            try:
                stamp = datetime.fromisoformat(reading["measured_at"])
            except (KeyError, TypeError, ValueError):
                raise ValueError(f"Измерение № {i+1}: некорректное время.") from None
            if stamp.tzinfo is None or stamp.utcoffset() is None:
                raise ValueError(f"Измерение № {i+1}: время без часового пояса.")
            if stamp > datetime.now().astimezone() + timedelta(minutes=2):
                raise ValueError(f"Измерение № {i+1}: время не может быть в будущем.")
            temperature = reading.get("temperature")
            if i == 0 and temperature is None:
                raise ValueError("Первое измерение должно содержать температуру.")
            if temperature is not None:
                try:
                    temperature = float(temperature)
                except (TypeError, ValueError):
                    raise ValueError(f"Измерение № {i+1}: некорректная температура.") from None
                if not math.isfinite(temperature) or not 25 <= temperature <= 50:
                    raise ValueError(f"Измерение № {i+1}: температура вне диапазона ввода.")
            try:
                sys = reading["systolic"]
                dia = reading["diastolic"]
                pulse = reading["pulse"]
                if any(type(num) is not int for num in (sys, dia, pulse)):
                    raise ValueError()
                if not 30 <= sys <= 350 or not 20 <= dia <= 250 or sys <= dia or not 15 <= pulse <= 300:
                    raise ValueError()
            except (KeyError, ValueError):
                raise ValueError(f"Измерение № {i+1}: проверьте АД и пульс.") from None
            if previous is not None:
                seconds = (stamp - previous).total_seconds()
                if not 300 <= seconds <= 600:
                    raise ValueError(f"Измерение № {i+1}: повтор должен быть через 5–10 минут.")
            previous = stamp
        return list(tags), shift

    def create_exam(self, details: dict, readings: list[dict]) -> int:
        tags, shift_label = self.validate_exam(details, readings)
        with self.connect() as db:
            employee = db.execute("SELECT * FROM employees WHERE id=?", (details["employee_id"],)).fetchone()
            if not employee:
                raise ValueError("Сотрудник не найден.")
            examined_at = readings[0]["measured_at"]
            saved_at = now_iso()
            cursor = db.execute("""
                INSERT INTO medical_exams (
                    employee_id, personnel_number, employee_name, employee_birth_date, employee_sex,
                    employee_department, employee_position, exam_type, shift_label,
                    examined_at, saved_at, nurse_name, complaints, complaint_tags, visual_notes,
                    intoxication_signs, alcohol_level, alcohol_unit, alcohol_result, drug_result,
                    conclusion, non_admission_reason, medical_comment, acknowledged_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                employee["id"], employee["personnel_number"], employee["full_name"],
                employee["birth_date"], employee["sex"], employee["department"],
                employee["position"], details["exam_type"], shift_label, examined_at,
                saved_at, " ".join(details["nurse_name"].split()), details["complaints"].strip(),
                json.dumps(list(tags), ensure_ascii=False), details["visual_notes"].strip(),
                int(details["intoxication_signs"]), float(details["alcohol_level"]),
                details["alcohol_unit"], details["alcohol_result"], details["drug_result"],
                details["conclusion"], details.get("non_admission_reason", "").strip(),
                details.get("medical_comment", "").strip(), saved_at,
            ))
            exam_id = int(cursor.lastrowid)
            for attempt_no, reading in enumerate(readings, start=1):
                db.execute("""
                    INSERT INTO measurements(
                        exam_id, attempt_no, measured_at, temperature, systolic, diastolic, pulse
                    ) VALUES (?, ?, ?, ?, ?, ?, ?)
                """, (
                    exam_id, attempt_no, reading["measured_at"], reading.get("temperature"),
                    reading["systolic"], reading["diastolic"], reading["pulse"],
                ))
            db.execute("""
                INSERT INTO audit_events(exam_id, event_type, description, created_at)
                VALUES (?, 'EXAM_CREATED', ?, ?)
            """, (exam_id, f"Создан осмотр, результат: {details['conclusion']}", saved_at))
            return exam_id

    def list_exams(self, query: str = "", period: str = "Все") -> list[sqlite3.Row]:
        """Find journal entries with proper Unicode case-insensitive search.

        SQLite LIKE/NOCASE only handles ASCII out of the box.  A locally
        registered Python function makes Cyrillic names and departments work
        regardless of letter case, and treats %, _ as literal text.
        """
        if period not in ("Все", "Сегодня", "7 дней"):
            raise ValueError("Неизвестный период фильтра.")
        term = query.strip().casefold()
        search_filter = ""
        params = []
        if term:
            search_filter = """AND (unicode_contains(e.employee_name, ?)
                            OR unicode_contains(e.personnel_number, ?)
                            OR unicode_contains(e.employee_department, ?)
                            OR unicode_contains(e.employee_position, ?))"""
            params.extend([term] * 4)
        period_filter = ""
        if period == "Сегодня":
            period_filter = "AND e.examined_at >= ? AND e.examined_at < ?"
            d = date.today()
            params.extend([d.isoformat() + "T", (d + timedelta(days=1)).isoformat() + "T"])
        elif period == "7 дней":
            period_filter = "AND e.examined_at >= ? AND e.examined_at < ?"
            d = date.today()
            params.extend([(d - timedelta(days=6)).isoformat() + "T",
                           (d + timedelta(days=1)).isoformat() + "T"])
        with self.connect() as db:
            db.create_function(
                "unicode_contains", 2,
                lambda haystack, needle: str(needle).casefold() in str(haystack or "").casefold(),
            )
            return db.execute(f"""
                SELECT e.*,
                    (SELECT temperature FROM measurements m WHERE m.exam_id=e.id
                     AND m.temperature IS NOT NULL ORDER BY attempt_no DESC LIMIT 1) AS last_temperature,
                    (SELECT systolic FROM measurements m WHERE m.exam_id=e.id
                     ORDER BY attempt_no DESC LIMIT 1) AS last_systolic,
                    (SELECT diastolic FROM measurements m WHERE m.exam_id=e.id
                     ORDER BY attempt_no DESC LIMIT 1) AS last_diastolic,
                    (SELECT pulse FROM measurements m WHERE m.exam_id=e.id
                     ORDER BY attempt_no DESC LIMIT 1) AS last_pulse,
                    (SELECT COUNT(*) FROM measurements m WHERE m.exam_id=e.id) AS readings_count
                FROM medical_exams e
                WHERE 1=1 {search_filter} {period_filter}
                ORDER BY e.examined_at DESC, e.id DESC
            """, params).fetchall()

    def employee_exams(self, employee_id: int, limit: int = 3) -> list[sqlite3.Row]:
        if not 1 <= limit <= 20:
            raise ValueError("Некорректное количество последних осмотров.")
        with self.connect() as db:
            return db.execute("""
                SELECT id, examined_at, exam_type, conclusion
                FROM medical_exams WHERE employee_id=?
                ORDER BY examined_at DESC, id DESC LIMIT ?
            """, (employee_id, limit)).fetchall()

    def same_day_exams(self, employee_id: int, exam_type: str, iso_date: str) -> list[sqlite3.Row]:
        with self.connect() as db:
            return db.execute("""
                SELECT id, examined_at, conclusion FROM medical_exams
                WHERE employee_id=? AND exam_type=? AND examined_at >= ? AND examined_at < ?
                ORDER BY examined_at DESC, id DESC
            """, (employee_id, exam_type, iso_date + "T",
                  (date.fromisoformat(iso_date) + timedelta(days=1)).isoformat() + "T")).fetchall()

    def get_exam(self, exam_id: int) -> tuple[sqlite3.Row | None, list[sqlite3.Row]]:
        with self.connect() as db:
            exam = db.execute("SELECT * FROM medical_exams WHERE id=?", (exam_id,)).fetchone()
            readings = db.execute("""
                SELECT * FROM measurements WHERE exam_id=? ORDER BY attempt_no
            """, (exam_id,)).fetchall()
            return exam, readings

    def audit_event(self, kind: str, description: str) -> None:
        with self.connect() as db:
            db.execute("""
                INSERT INTO audit_events(exam_id, event_type, description, created_at)
                VALUES (NULL, ?, ?, ?)
            """, (kind, description, now_iso()))

    def check_integrity(self) -> tuple[bool, str]:
        """Read-only SQLite quick check, including foreign key references."""
        with self.connect() as db:
            checks = [row[0] for row in db.execute("PRAGMA quick_check").fetchall()]
            invalid_refs = db.execute("PRAGMA foreign_key_check").fetchall()
        if checks != ["ok"]:
            return False, "; ".join(str(item) for item in checks[:5])
        if invalid_refs:
            return False, f"Найдены нарушения связей таблиц: {len(invalid_refs)}"
        return True, "SQLite: ошибок целостности не обнаружено."

    def backup(self, destination: Path) -> None:
        """Produce a complete SQLite snapshot; never leave a half-written backup.

        Write to a sibling temporary file, then atomically move the complete
        snapshot to its final path.  Existing backups remain intact if the
        write fails partway through.
        """
        destination = Path(destination)
        destination.parent.mkdir(parents=True, exist_ok=True)
        if destination.resolve() == self.db_path.resolve():
            raise ValueError("Путь резервной копии не должен совпадать с рабочей базой.")
        temp_fd, temp_name = tempfile.mkstemp(prefix=".medcontrol_backup_",
                                               suffix=".sqlite3", dir=destination.parent)
        os.close(temp_fd)
        temporary = Path(temp_name)
        try:
            with self.connect() as source:
                target = sqlite3.connect(temporary, timeout=10)
                try:
                    source.backup(target)
                    check = target.execute("PRAGMA quick_check").fetchone()
                    if check is None or check[0] != "ok":
                        raise sqlite3.DatabaseError("Резервная копия не прошла проверку SQLite.")
                finally:
                    target.close()
            os.replace(temporary, destination)
        finally:
            temporary.unlink(missing_ok=True)
        # An optional audit log write must not report failure after a valid
        # SQLite backup has already been safely written.
        try:
            self.audit_event("DATABASE_BACKUP", f"Создана резервная копия: {destination.name}")
        except (sqlite3.Error, OSError):
            pass


