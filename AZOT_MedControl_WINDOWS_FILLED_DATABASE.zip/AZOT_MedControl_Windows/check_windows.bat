@echo off
setlocal EnableExtensions DisableDelayedExpansion
call "%~dp0start.bat" /check
exit /b %errorlevel%
