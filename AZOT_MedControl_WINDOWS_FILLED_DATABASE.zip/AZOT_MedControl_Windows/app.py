"""АЗОТ · Медконтроль v4.4 — демонстрационный настольный интерфейс.

Python 3.10+, tkinter/ttk + SQLite, только стандартная библиотека.
ВНИМАНИЕ: приложение не подходит для юридически значимых медосмотров,
не имеет ЭП, аутентификации, шифрования или разграничения доступа.
"""

from __future__ import annotations

import csv
import json
import os
import sqlite3
import sys
import tempfile
import traceback
import tkinter as tk
import webbrowser
from datetime import datetime
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

from database import (
    ALCOHOL_RESULTS, BACKUPS_DIR, CONCLUSIONS, DATA_DIR, DRUG_RESULTS,
    EXAM_TYPES, EXPORTS_DIR, SIGNS_OPTIONS, SYMPTOM_OPTIONS, Store, display_date,
    display_datetime, format_number, now_iso, parse_float, parse_int, safe_csv_cell,
    user_profile_db_path,
)

ROOT = Path(__file__).resolve().parent
GREEN = "#2EB735"
GREEN_DARK = "#198C2C"
GREEN_LIGHT = "#EAF7EB"
NAV = "#142E27"
NAV_HOVER = "#234438"
NAV_ACTIVE = "#2D5140"
BG = "#F2F6F4"
WHITE = "#FFFFFF"
TEXT = "#1A2B25"
MUTED = "#6E8078"
BORDER = "#DEE8E2"
RED = "#C9493E"
RED_LIGHT = "#FFF0EE"
BLUE = "#2E6D84"
BLUE_LIGHT = "#EAF3F7"
FONT = "Segoe UI"
REASON_TEMPLATES = (
    "Отклонения показателей АД / пульса",
    "Температура / признаки заболевания",
    "Жалобы на самочувствие",
    "Признаки опьянения",
    "Требуется дополнительная оценка / консультация врача",
)


def label(parent, text, size=10, bold=False, color=TEXT, bg=WHITE, **opts):
    return tk.Label(parent, text=text, bg=bg, fg=color,
                    font=(FONT, size, "bold" if bold else "normal"),
                    **opts)


def button(parent, text, command, kind="primary", **kw):
    style = {"primary": "Primary.TButton", "ghost": "Ghost.TButton",
             "subtle": "Subtle.TButton", "red": "Danger.TButton"}.get(kind, "Primary.TButton")
    return ttk.Button(parent, text=text, command=command, style=style, **kw)


def line(parent, color=BORDER, height=1):
    return tk.Frame(parent, bg=color, height=height)


def card(parent, title=None, eyebrow=None, subtitle=None, bg=WHITE, pady=16):
    """Minimal square-corner card: reliable appearance across Tk 8.6 platforms."""
    border = tk.Frame(parent, bg=BORDER, padx=1, pady=1)
    inside = tk.Frame(border, bg=bg, padx=22, pady=pady)
    inside.pack(fill="both", expand=True)
    if eyebrow:
        label(inside, eyebrow, 9, True, GREEN_DARK, bg=bg).pack(anchor="w", pady=(0, 5))
    if title:
        label(inside, title, 13, True, bg=bg).pack(anchor="w")
    if subtitle:
        label(inside, subtitle, 9, color=MUTED, bg=bg).pack(anchor="w", pady=(4, 12))
    elif title:
        line(inside, color="#EBF1ED").pack(fill="x", pady=(12, 15))
    body = tk.Frame(inside, bg=bg)
    body.pack(fill="both", expand=True)
    return border, body


def field_label(parent, title):
    return label(parent, title, 9, True, color="#53675D", bg=WHITE)


def entry_text(parent, **kw):
    return tk.Text(parent, bg="#FCFDFC", fg=TEXT, insertbackground=TEXT,
                   font=(FONT, 10), relief="flat", bd=0,
                   highlightthickness=1, highlightbackground=BORDER,
                   highlightcolor=GREEN, wrap="word", padx=10, pady=8, **kw)


def decode_symptoms(value):
    """An old or manually modified database must not crash an open/extract action."""
    try:
        parsed = json.loads(value or "[]")
        return [x for x in parsed if isinstance(x, str)] if isinstance(parsed, list) else []
    except (json.JSONDecodeError, TypeError):
        return []


class EmployeeDialog(tk.Toplevel):
    def __init__(self, app: "App", employee: sqlite3.Row | None = None):
        super().__init__(app)
        self.app = app
        self.employee = employee
        self.title("Карточка сотрудника · АЗОТ")
        dialog_w = min(590, max(390, self.winfo_screenwidth() - 55))
        self.geometry(f"{dialog_w}x590")
        self.resizable(False, False)
        self.configure(bg=BG)
        self.transient(app)
        # A scrollable dialog keeps Save / Cancel reachable at high Windows DPI,
        # even on short 1024x600 laptop displays.
        viewport = tk.Frame(self, bg=BG)
        viewport.pack(fill="both", expand=True)
        self.dialog_canvas = tk.Canvas(viewport, bg=BG, bd=0, highlightthickness=0)
        scrollbar = ttk.Scrollbar(viewport, orient="vertical", command=self.dialog_canvas.yview)
        self.dialog_canvas.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side="right", fill="y")
        self.dialog_canvas.pack(side="left", fill="both", expand=True)
        wrap = tk.Frame(self.dialog_canvas, bg=BG, padx=22, pady=22)
        win_id = self.dialog_canvas.create_window((0, 0), anchor="nw", window=wrap)
        wrap.bind("<Configure>", lambda _: self.dialog_canvas.configure(
            scrollregion=self.dialog_canvas.bbox("all")))
        self.dialog_canvas.bind("<Configure>", lambda e: self.dialog_canvas.itemconfigure(
            win_id, width=e.width))
        label(wrap, "СОТРУДНИК / СПРАВОЧНИК", 9, True, GREEN_DARK, bg=BG).pack(anchor="w")
        label(wrap, "Изменить карточку" if employee else "Новый сотрудник", 20, True,
              bg=BG).pack(anchor="w", pady=(2, 15))
        outer, form = card(wrap, pady=17)
        outer.pack(fill="x")
        self.number = tk.StringVar(value=employee["personnel_number"] if employee else "")
        self.full_name = tk.StringVar(value=employee["full_name"] if employee else "")
        self.birth = tk.StringVar(value=display_date(employee["birth_date"]) if employee else "")
        self.sex = tk.StringVar(value=employee["sex"] if employee else "")
        self.department = tk.StringVar(value=employee["department"] if employee else "")
        self.position = tk.StringVar(value=employee["position"] if employee else "")
        form.columnconfigure(1, weight=1)
        for r, (caption, variable) in enumerate((("Табельный номер", self.number),
                                                  ("ФИО сотрудника", self.full_name),
                                                  ("Дата рождения", self.birth))):
            field_label(form, caption).grid(row=r, column=0, sticky="w", pady=9, padx=(0, 14))
            ttk.Entry(form, textvariable=variable).grid(row=r, column=1, sticky="ew", pady=9)
        field_label(form, "Пол").grid(row=3, column=0, sticky="w", pady=9)
        ttk.Combobox(form, state="readonly", textvariable=self.sex,
                     values=("М", "Ж"), width=13).grid(row=3, column=1, sticky="w", pady=9)
        for r, (caption, variable) in enumerate((("Цех / подразделение", self.department),
                                                  ("Должность / профессия", self.position)), 4):
            field_label(form, caption).grid(row=r, column=0, sticky="w", pady=9, padx=(0, 14))
            ttk.Entry(form, textvariable=variable).grid(row=r, column=1, sticky="ew", pady=9)
        bar = tk.Frame(wrap, bg=BG)
        bar.pack(fill="x", pady=(18, 0))
        button(bar, "Сохранить карточку", self.save).pack(side="right")
        button(bar, "Отмена", self.cancel, "ghost").pack(side="right", padx=(0, 9))
        self.bind("<Escape>", lambda _: self.cancel())
        self.protocol("WM_DELETE_WINDOW", self.cancel)
        self._original_fields = self._fields()
        self._install_dialog_wheel(wrap)
        # Never let the fixed form force the window below the usable screen;
        # the scrollbar exposes the complete content when necessary.
        self.update_idletasks()
        max_h = max(350, self.winfo_screenheight() - 85)
        dialog_h = min(max(590, wrap.winfo_reqheight() + 10), max_h)
        self.geometry(f"{dialog_w}x{dialog_h}")
        self.grab_set()
        self.after(60, self.focus_force)

    def _fields(self):
        return tuple(v.get() for v in (self.number, self.full_name, self.birth,
                                       self.sex, self.department, self.position))

    def cancel(self):
        if self._fields() != self._original_fields and not messagebox.askyesno(
                "Несохранённые изменения",
                "В карточке сотрудника есть несохранённые изменения. Закрыть без сохранения?",
                parent=self):
            return
        self.destroy()

    def _install_dialog_wheel(self, widget):
        """Scroll the employee form with a mouse wheel on labels and buttons."""
        def on_wheel(event):
            if getattr(event, "num", None) == 4:
                delta = -2
            elif getattr(event, "num", None) == 5:
                delta = 2
            elif getattr(event, "delta", 0):
                delta = -1 if event.delta > 0 else 1
            else:
                return
            self.dialog_canvas.yview_scroll(delta, "units")
            return "break"

        for sequence in ("<MouseWheel>", "<Button-4>", "<Button-5>"):
            widget.bind(sequence, on_wheel)
        for child in widget.winfo_children():
            if not isinstance(child, (ttk.Entry, ttk.Combobox, tk.Text, ttk.Treeview)):
                self._install_dialog_wheel(child)

    def save(self):
        try:
            self.app.store.save_employee(
                self.number.get(), self.full_name.get(), self.birth.get(), self.sex.get(),
                self.employee["id"] if self.employee else None,
                department=self.department.get(), position=self.position.get())
        except (ValueError, sqlite3.Error) as exc:
            messagebox.showerror("Проверьте данные", str(exc), parent=self)
            return
        self.app.refresh_employees()
        self.app.refresh_employee_choices()
        self.app.refresh_dashboard()
        self.destroy()


class App(tk.Tk):
    def __init__(self, store: Store | None = None, start_hidden: bool = False):
        super().__init__()
        if start_hidden:
            self.withdraw()
        self.store = store or Store()
        self.title("АЗОТ | Медицинский контроль · демонстрационная версия")
        # Fit on common Windows laptop screens. The exam page scrolls vertically.
        screen_w, screen_h = self.winfo_screenwidth(), self.winfo_screenheight()
        # Small remote desktops / high DPI sometimes expose a logical screen
        # below 760x550.  Never force the top-level window off-screen.
        window_w = min(screen_w, min(1390, max(620, screen_w - 40)))
        window_h = min(screen_h, min(860, max(400, screen_h - 90)))
        self.geometry(f"{window_w}x{window_h}+{max(0, (screen_w-window_w)//2)}+{max(0, (screen_h-window_h)//3)}")
        self.minsize(min(950, window_w), min(625, window_h))
        self.configure(bg=BG)
        self.readings: list[dict] = []
        self.reading_employee_id: int | None = None
        self._clean_nurse_name = ""  # saved-entry convenience is not unsaved work
        self.employee_lookup: dict[str, int] = {}
        self.page = "overview"
        self.nav_buttons = {}
        self.page_frames = {}
        self._set_styles()
        self._build_shell()
        self._build_dashboard()
        self._build_exam_page()
        self._build_employees_page()
        self._build_journal_page()
        self._build_about_page()
        self.refresh_employees()
        self.refresh_employee_choices()
        self.refresh_journal()
        self.refresh_dashboard()
        self.navigate("overview")
        self.protocol("WM_DELETE_WINDOW", self.close_app)

    def _user_data_mode(self) -> bool:
        """True only when the normal Store selected the actual user-profile DB."""
        return self.store.db_path.resolve() == user_profile_db_path().resolve()

    def _output_dir(self, name: str) -> Path:
        if self._user_data_mode():
            return self.store.db_path.parent.parent / name
        return ROOT / name

    def report_callback_exception(self, exception, value, tb):
        """Tkinter swallows callback exceptions: preserve details even in a read-only folder."""
        candidates = [self._output_dir("logs") / "runtime_errors.log"]
        if os.environ.get("LOCALAPPDATA"):
            candidates.append(Path(os.environ["LOCALAPPDATA"]) / "AZOT_MedControl" / "logs" / "runtime_errors.log")
        candidates.append(Path(tempfile.gettempdir()) / "AZOT_MedControl" / "runtime_errors.log")
        note = "\n\nНе удалось создать журнал ошибки."
        for target in candidates:
            try:
                target.parent.mkdir(parents=True, exist_ok=True)
                with target.open("a", encoding="utf-8") as fh:
                    fh.write(f"\n----- {now_iso()} -----\n")
                    fh.write("".join(traceback.format_exception(exception, value, tb)))
                note = f"\n\nТехнический журнал: {target}"
                break
            except OSError:
                continue
        try:
            messagebox.showerror("Ошибка работы программы",
                                 f"Возникла ошибка: {value}{note}", parent=self)
        except tk.TclError:
            pass

    def _set_styles(self):
        style = ttk.Style(self)
        if "clam" in style.theme_names():
            style.theme_use("clam")
        style.configure("TButton", font=(FONT, 10, "bold"), padding=(15, 10), relief="flat")
        style.configure("Primary.TButton", background=GREEN_DARK, foreground=WHITE,
                        bordercolor=GREEN_DARK, lightcolor=GREEN_DARK, darkcolor=GREEN_DARK)
        style.map("Primary.TButton", background=[("pressed", "#116E21"), ("active", GREEN)],
                  foreground=[("disabled", "#CDDBD0"), ("active", WHITE)])
        style.configure("Ghost.TButton", background=WHITE, foreground=TEXT,
                        bordercolor=BORDER, lightcolor=WHITE, darkcolor=WHITE)
        style.map("Ghost.TButton", background=[("active", "#EAF1EC")])
        style.configure("Subtle.TButton", background=GREEN_LIGHT, foreground=GREEN_DARK,
                        bordercolor=GREEN_LIGHT, lightcolor=GREEN_LIGHT, darkcolor=GREEN_LIGHT)
        style.map("Subtle.TButton", background=[("active", "#DCF2DB")])
        style.configure("Danger.TButton", background=RED_LIGHT, foreground=RED,
                        bordercolor=RED_LIGHT, lightcolor=RED_LIGHT, darkcolor=RED_LIGHT)
        style.map("Danger.TButton", background=[("active", "#FFE2DD")])
        style.configure("TEntry", padding=(9, 8), font=(FONT, 10), foreground=TEXT,
                        fieldbackground=WHITE, bordercolor=BORDER, lightcolor=BORDER)
        style.configure("TCombobox", padding=(9, 7), font=(FONT, 10), foreground=TEXT,
                        fieldbackground=WHITE, bordercolor=BORDER, arrowsize=17)
        style.map("TCombobox", fieldbackground=[("readonly", WHITE)],
                  selectbackground=[("readonly", WHITE)], selectforeground=[("readonly", TEXT)])
        style.configure("TCheckbutton", font=(FONT, 10), background=WHITE, foreground=TEXT)
        style.map("TCheckbutton", background=[("active", WHITE)])
        style.configure("Treeview", font=(FONT, 10), background=WHITE, foreground=TEXT,
                        fieldbackground=WHITE, rowheight=38, borderwidth=0, relief="flat")
        style.configure("Treeview.Heading", font=(FONT, 9, "bold"), background="#EDF3EF",
                        foreground="#52665C", padding=(8, 10), relief="flat")
        style.map("Treeview", background=[("selected", "#DFF1E1")],
                  foreground=[("selected", "#183F23")])
        style.configure("Vertical.TScrollbar", troughcolor=BG, background="#C5D3CB")

    def _build_shell(self):
        # Layout: permanent sidebar, sticky top header, swap-in content pages.
        self.sidebar = tk.Frame(self, bg=NAV, width=234)
        self.sidebar.pack(side="left", fill="y")
        self.sidebar.pack_propagate(False)
        brand = tk.Frame(self.sidebar, bg=NAV, padx=25, pady=22)
        brand.pack(fill="x")
        logo = label(brand, "АЗОТ", 29, True, color=GREEN, bg=NAV)
        logo.pack(anchor="w")
        label(brand, "КАО «АЗОТ»  ·  КЕМЕРОВО", 8, True,
              color="#A9BBB2", bg=NAV).pack(anchor="w", pady=(0, 18))
        line(brand, color="#385448").pack(fill="x")
        label(self.sidebar, "РАБОЧЕЕ МЕСТО", 8, True, color="#91A69B",
              bg=NAV).pack(anchor="w", padx=26, pady=(18, 12))
        for key, text in (("overview", "01    Обзор"), ("exam", "02    Новый осмотр"),
                          ("employees", "03    Сотрудники"), ("journal", "04    Журнал"),
                          ("about", "05    О системе / UML")):
            self.nav_buttons[key] = tk.Button(
                self.sidebar, text=text, command=lambda k=key: self.navigate(k),
                font=(FONT, 11, "bold"), anchor="w", padx=25, pady=15,
                bg=NAV, fg="#C8D8CE", relief="flat", borderwidth=0,
                activebackground=NAV_ACTIVE, activeforeground=WHITE, cursor="hand2",
                highlightthickness=0, takefocus=0)
            self.nav_buttons[key].pack(fill="x", pady=1)
        tk.Frame(self.sidebar, bg=NAV).pack(fill="both", expand=True)
        bottom = tk.Frame(self.sidebar, bg="#1A3C30", padx=19, pady=16)
        bottom.pack(fill="x", padx=14, pady=18)
        label(bottom, "●  ЛОКАЛЬНЫЙ РЕЖИМ", 9, True, color="#7BDF89",
              bg="#1A3C30").pack(anchor="w")
        label(bottom, "SQLite  ·  Python  ·  Windows", 9, color="#ADCCBA",
              bg="#1A3C30").pack(anchor="w", pady=(5, 0))
        self.main = tk.Frame(self, bg=BG)
        self.main.pack(side="left", fill="both", expand=True)
        head = tk.Frame(self.main, bg=WHITE, height=88)
        head.pack(fill="x")
        head.pack_propagate(False)
        line(self.main, color=GREEN, height=4).pack(fill="x")
        left = tk.Frame(head, bg=WHITE)
        left.pack(side="left", padx=32, pady=14)
        self.header_eyebrow = label(left, "МЕДИЦИНСКАЯ СЛУЖБА / КЕМЕРОВО", 9, True,
                                    GREEN_DARK)
        self.header_eyebrow.pack(anchor="w")
        self.header_title = label(left, "Обзор", 21, True)
        self.header_title.pack(anchor="w", pady=(2, 0))
        right = tk.Frame(head, bg=WHITE)
        right.pack(side="right", padx=32)
        label(right, "ДЕМОНСТРАЦИОННЫЙ ПРОТОТИП", 9, True,
              color=RED).pack(anchor="e")
        self.top_time = label(right, "", 9, color=MUTED)
        self.top_time.pack(anchor="e", pady=(5, 0))
        self._refresh_clock()
        self.content = tk.Frame(self.main, bg=BG)
        self.content.pack(fill="both", expand=True)
        footer = tk.Frame(self.main, bg="#E8EEE9", height=36)
        footer.pack(fill="x", side="bottom", before=self.content)
        footer.pack_propagate(False)
        label(footer, "ТЕСТОВЫЙ МАКЕТ   •   Нет электронной подписи, авторизации и защиты медданных — не использовать для реальных допусков",
              9, color="#6B5147", bg="#E8EEE9").pack(side="left", padx=22, pady=9)

    def _refresh_clock(self):
        self.top_time.configure(text=datetime.now().strftime("%d.%m.%Y   ·   %H:%M"))
        self.after(45000, self._refresh_clock)

    def _page(self, name):
        frame = tk.Frame(self.content, bg=BG)
        self.page_frames[name] = frame
        return frame

    def navigate(self, page):
        scrollable = ("exam", "overview", "about")
        if self.page in scrollable and page not in scrollable:
            self._unbind_exam_scroll()
        self.page = page
        titles = {"overview": "Обзор смены", "exam": "Новый осмотр",
                  "employees": "Сотрудники", "journal": "Журнал осмотров",
                  "about": "О системе и архитектура"}
        self.header_title.configure(text=titles.get(page, "Медконтроль"))
        for key, btn in self.nav_buttons.items():
            btn.configure(bg=NAV_ACTIVE if key == page else NAV,
                          fg=WHITE if key == page else "#C8D8CE")
        for frame in self.page_frames.values():
            frame.pack_forget()
        self.page_frames[page].pack(fill="both", expand=True)
        if page == "overview":
            self.refresh_dashboard()
        elif page == "journal":
            self.refresh_journal()
        elif page == "employees":
            self.refresh_employees()
        if page in scrollable:
            self._bind_exam_scroll()
            canvas = {"exam": self.exam_canvas,
                      "overview": self.overview_canvas,
                      "about": self.about_canvas}[page]
            canvas.yview_moveto(0)

    # -------------------------------- Overview --------------------------------
    def _build_dashboard(self):
        page = self._page("overview")
        viewport = tk.Frame(page, bg=BG)
        viewport.pack(fill="both", expand=True)
        self.overview_canvas = tk.Canvas(viewport, bg=BG, highlightthickness=0, bd=0)
        yscroll = ttk.Scrollbar(viewport, orient="vertical", command=self.overview_canvas.yview)
        self.overview_canvas.configure(yscrollcommand=yscroll.set)
        yscroll.pack(side="right", fill="y")
        self.overview_canvas.pack(side="left", fill="both", expand=True)
        frame = tk.Frame(self.overview_canvas, bg=BG, padx=30, pady=23)
        window_id = self.overview_canvas.create_window((0, 0), window=frame, anchor="nw")
        frame.bind("<Configure>",
                   lambda _: self.overview_canvas.configure(scrollregion=self.overview_canvas.bbox("all")))
        self.overview_canvas.bind("<Configure>",
                                  lambda e: self.overview_canvas.itemconfigure(window_id, width=e.width))
        hero = tk.Frame(frame, bg=NAV, height=178)
        hero.pack(fill="x")
        hero.pack_propagate(False)
        hero_left = tk.Frame(hero, bg=NAV)
        hero_left.pack(side="left", fill="both", expand=True, padx=28, pady=13)
        label(hero_left, "КАО «АЗОТ»   /   МЕДИЦИНСКИЙ ДОПУСК", 9, True, "#7DE58C", NAV).pack(anchor="w")
        label(hero_left, "Контроль перед началом смены", 21, True, WHITE, NAV).pack(anchor="w", pady=(8, 4))
        label(hero_left, "Предсменные и предрейсовые осмотры · Кемерово", 10,
              color="#C4D5CA", bg=NAV).pack(anchor="w")
        button(hero_left, "Начать осмотр  →", lambda: self.navigate("exam")).pack(anchor="w", pady=(10, 0))
        symbol = tk.Canvas(hero, width=205, height=176, bg=NAV, highlightthickness=0)
        symbol.pack(side="right", padx=35)
        symbol.create_oval(35, 22, 169, 156, outline="#397554", width=2)
        symbol.create_oval(53, 40, 151, 138, outline="#2BA63E", width=2)
        symbol.create_text(103, 87, text="N₂", font=(FONT, 38, "bold"), fill="#8EE59C")
        symbol.create_text(103, 133, text="AZOT  /  HEALTH", font=(FONT, 9, "bold"), fill="#C8D8CF")
        metrics = tk.Frame(frame, bg=BG)
        metrics.pack(fill="x", pady=(17, 16))
        for i in range(4):
            metrics.columnconfigure(i, weight=1, uniform="metric")
        self.metric_values = {}
        for col, (key, title, accent) in enumerate((
            ("all", "Осмотров сегодня", GREEN_DARK),
            ("yes", "Допущено", GREEN),
            ("no", "Не допущено", RED),
            ("employees", "Сотрудников в базе", BLUE),
        )):
            holder = tk.Frame(metrics, bg=BORDER, padx=1, pady=1)
            holder.grid(row=0, column=col, sticky="nsew", padx=(0 if col == 0 else 5, 5 if col != 3 else 0))
            inside = tk.Frame(holder, bg=WHITE, padx=17, pady=15)
            inside.pack(fill="both", expand=True)
            tk.Frame(inside, bg=accent, height=3, width=38).pack(anchor="w")
            self.metric_values[key] = label(inside, "0", 25, True, TEXT)
            self.metric_values[key].pack(anchor="w", pady=(9, 0))
            label(inside, title, 9, color=MUTED).pack(anchor="w", pady=(1, 0))
        bottom = tk.Frame(frame, bg=BG)
        bottom.pack(fill="both", expand=True)
        bottom.columnconfigure(0, weight=3)
        bottom.columnconfigure(1, weight=2)
        bottom.rowconfigure(0, weight=1)
        activity_outer, activity = card(bottom, "Последние осмотры", pady=18)
        activity_outer.grid(row=0, column=0, sticky="nsew", padx=(0, 10))
        self.dashboard_tree = ttk.Treeview(activity, columns=("when", "name", "result"),
                                           show="headings", height=5, selectmode="browse")
        for c, name, width in (("when", "Дата / время", 160),
                               ("name", "Сотрудник", 230), ("result", "Заключение", 130)):
            self.dashboard_tree.heading(c, text=name)
            self.dashboard_tree.column(c, width=width, stretch=(c == "name"))
        self.dashboard_tree.pack(fill="both", expand=True)
        self.dashboard_tree.bind("<Double-1>", lambda _: self._open_dashboard_exam())
        self.dashboard_empty = label(activity, "Записей пока нет. Начните с добавления сотрудника.", 9, color=MUTED)
        quick_outer, quick = card(bottom, "Рабочий процесс", pady=18)
        quick_outer.grid(row=0, column=1, sticky="nsew")
        for index, (headline, caption) in enumerate((
            ("Выберите сотрудника", "Справочник и табельный номер"),
            ("Внесите показатели", "Температура, АД, пульс, алкотест"),
            ("Оформите заключение", "Результат определяет медработник"),
        ), 1):
            row = tk.Frame(quick, bg=WHITE)
            row.pack(fill="x", pady=(5, 10))
            boxnum = tk.Frame(row, bg=GREEN_LIGHT, width=32, height=32)
            boxnum.pack(side="left", anchor="n")
            boxnum.pack_propagate(False)
            label(boxnum, str(index), 11, True, GREEN_DARK, GREEN_LIGHT).pack(expand=True)
            txt = tk.Frame(row, bg=WHITE)
            txt.pack(side="left", padx=11, fill="x")
            label(txt, headline, 10, True).pack(anchor="w")
            label(txt, caption, 9, color=MUTED).pack(anchor="w", pady=(3, 0))
        line(quick).pack(fill="x", pady=(5, 13))
        button(quick, "Открыть журнал  ↗", lambda: self.navigate("journal"), "subtle").pack(anchor="w")

    def refresh_dashboard(self):
        if not hasattr(self, "metric_values"):
            return
        exams = self.store.list_exams()
        today = datetime.now().date().isoformat()
        todays = [e for e in exams if str(e["examined_at"]).startswith(today)]
        vals = {"all": len(todays), "yes": sum(e["conclusion"] == "Допущен" for e in todays),
                "no": sum(e["conclusion"] == "Не допущен" for e in todays),
                "employees": len(self.store.list_employees())}
        for key, val in vals.items():
            self.metric_values[key].configure(text=str(val))
        self.dashboard_tree.delete(*self.dashboard_tree.get_children())
        for e in exams[:8]:
            self.dashboard_tree.insert("", "end", iid=str(e["id"]), values=(
                display_datetime(e["examined_at"])[:16], e["employee_name"], e["conclusion"]),
                tags=("refused" if e["conclusion"] == "Не допущен" else "admitted",))
        self.dashboard_tree.tag_configure("admitted", background="#F2FAF3")
        self.dashboard_tree.tag_configure("refused", background="#FFF0EF")
        if exams:
            self.dashboard_empty.pack_forget()
        else:
            self.dashboard_empty.pack(anchor="w", pady=16)

    def _open_dashboard_exam(self):
        selection = self.dashboard_tree.selection()
        if selection:
            self.open_exam_details(int(selection[0]))

    # ------------------------------- Employees -------------------------------
    def _build_employees_page(self):
        page = self._page("employees")
        outer = tk.Frame(page, bg=BG, padx=30, pady=23)
        outer.pack(fill="both", expand=True)
        toolbar = tk.Frame(outer, bg=BG)
        toolbar.pack(fill="x", pady=(0, 18))
        titlebox = tk.Frame(toolbar, bg=BG)
        titlebox.pack(side="left")
        label(titlebox, "Реестр работников", 17, True, bg=BG).pack(anchor="w")
        self.employee_counter = label(titlebox, "Сотрудников: 0", 9, color=MUTED, bg=BG)
        self.employee_counter.pack(anchor="w", pady=(3, 0))
        button(toolbar, "+ Добавить сотрудника", lambda: EmployeeDialog(self)).pack(side="right")
        button(toolbar, "Изменить", self.edit_employee, "ghost").pack(side="right", padx=10)
        searchbar, searchcontent = card(outer, pady=14)
        searchbar.pack(fill="x", pady=(0, 13))
        field_label(searchcontent, "ПОИСК ПО ФИО, ТАБЕЛЬНОМУ НОМЕРУ, ЦЕХУ ИЛИ ДОЛЖНОСТИ").pack(anchor="w", pady=(0, 7))
        self.employee_search = tk.StringVar()
        search = ttk.Entry(searchcontent, textvariable=self.employee_search)
        search.pack(fill="x")
        self.employee_search.trace_add("write", lambda *_: self.refresh_employees())
        frame, container = card(outer, pady=14)
        frame.pack(fill="both", expand=True)
        cols = ("number", "name", "department", "position", "birth", "sex")
        self.employee_tree = ttk.Treeview(container, columns=cols, show="headings", selectmode="browse")
        for col, heading, width in (("number", "Табельный №", 112), ("name", "ФИО", 280),
                                    ("department", "Цех", 140), ("position", "Должность", 180),
                                    ("birth", "Дата рождения", 135), ("sex", "Пол", 55)):
            self.employee_tree.heading(col, text=heading)
            self.employee_tree.column(col, width=width, anchor="w", stretch=(col == "name"))
        scrollbar = ttk.Scrollbar(container, orient="vertical", command=self.employee_tree.yview)
        self.employee_tree.configure(yscrollcommand=scrollbar.set)
        self.employee_tree.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        self.employee_tree.bind("<Double-1>", lambda _: self.edit_employee())

    def refresh_employees(self):
        if not hasattr(self, "employee_tree"):
            return
        employees = self.store.list_employees()
        query = self.employee_search.get().strip().casefold()
        shown = [e for e in employees if not query or any(
            query in str(e[field]).casefold()
            for field in ("full_name", "personnel_number", "department", "position"))]
        self.employee_tree.delete(*self.employee_tree.get_children())
        for e in shown:
            self.employee_tree.insert("", "end", iid=str(e["id"]), values=(
                e["personnel_number"], e["full_name"], e["department"], e["position"],
                display_date(e["birth_date"]), e["sex"]))
        self.employee_counter.configure(text=f"Всего сотрудников: {len(employees)}  ·  найдено: {len(shown)}")

    def edit_employee(self):
        selection = self.employee_tree.selection()
        if not selection:
            messagebox.showinfo("Карточка", "Выберите сотрудника в списке.", parent=self)
            return
        employee = self.store.get_employee(int(selection[0]))
        if employee is not None:
            EmployeeDialog(self, employee)

    def refresh_employee_choices(self):
        if not hasattr(self, "employee_combobox"):
            return
        old_id = self.employee_lookup.get(self.employee_choice.get())
        self.employee_lookup = {
            f"{e['personnel_number']}   ·   {e['full_name']}": e["id"]
            for e in self.store.list_employees()
        }
        self.employee_combobox.configure(values=list(self.employee_lookup))
        self.employee_choice.set(next((k for k, v in self.employee_lookup.items() if v == old_id), ""))
        self.update_employee_history()

    # ------------------------------- New exam -------------------------------
    def _build_exam_page(self):
        page = self._page("exam")
        container = tk.Frame(page, bg=BG)
        container.pack(fill="both", expand=True)
        self.exam_canvas = tk.Canvas(container, bg=BG, highlightthickness=0, bd=0)
        scroll = ttk.Scrollbar(container, orient="vertical", command=self.exam_canvas.yview)
        self.exam_canvas.configure(yscrollcommand=scroll.set)
        scroll.pack(side="right", fill="y")
        self.exam_canvas.pack(side="left", fill="both", expand=True)
        form = tk.Frame(self.exam_canvas, bg=BG, padx=30, pady=22)
        win = self.exam_canvas.create_window((0, 0), window=form, anchor="nw")
        form.bind("<Configure>", lambda _: self.exam_canvas.configure(scrollregion=self.exam_canvas.bbox("all")))
        self.exam_canvas.bind("<Configure>", lambda e: self.exam_canvas.itemconfigure(win, width=e.width))
        header = tk.Frame(form, bg=BG)
        header.pack(fill="x", pady=(0, 15))
        label(header, "Форма медицинского осмотра", 17, True, bg=BG).pack(anchor="w")
        label(header, "Заполняется медработником · результат не определяется автоматически",
              9, color=MUTED, bg=BG).pack(anchor="w", pady=(4, 0))

        c1, info = card(form, "Сведения об осмотре", "ШАГ 01", pady=18)
        c1.pack(fill="x", pady=(0, 12))
        info.columnconfigure(0, weight=3)
        info.columnconfigure(1, weight=2)
        self.employee_choice = tk.StringVar()
        self.exam_type = tk.StringVar(value=EXAM_TYPES[0])
        self.nurse_name = tk.StringVar()
        self.shift_label = tk.StringVar(value="Не указана")
        field_label(info, "СОТРУДНИК").grid(row=0, column=0, sticky="w", pady=(0, 6), padx=(0, 15))
        field_label(info, "ТИП ОСМОТРА").grid(row=0, column=1, sticky="w", pady=(0, 6))
        self.employee_combobox = ttk.Combobox(info, textvariable=self.employee_choice,
                                               state="readonly", width=50)
        self.employee_combobox.grid(row=1, column=0, sticky="ew", padx=(0, 15))
        self.employee_combobox.bind("<<ComboboxSelected>>", self.on_employee_selected)
        ttk.Combobox(info, textvariable=self.exam_type, values=EXAM_TYPES,
                     state="readonly").grid(row=1, column=1, sticky="ew")
        field_label(info, "ФИО МЕДРАБОТНИКА").grid(row=2, column=0, sticky="w", pady=(14, 6))
        field_label(info, "СМЕНА (НЕОБЯЗАТЕЛЬНО)").grid(row=2, column=1, sticky="w", pady=(14, 6))
        ttk.Entry(info, textvariable=self.nurse_name).grid(row=3, column=0, sticky="ew", padx=(0, 15))
        ttk.Combobox(info, textvariable=self.shift_label, state="normal",
                     values=("Не указана", "Дневная", "Ночная", "1-я", "2-я", "3-я", "4-я"),
                     width=20).grid(row=3, column=1, sticky="ew")
        self.employee_history = label(info, "Последние осмотры: выберите сотрудника", 9, color=MUTED,
                                      wraplength=850, justify="left")
        self.employee_history.grid(row=4, column=0, columnspan=2, sticky="w", pady=(13, 0))

        c2, measure = card(form, "Основные показатели", "ШАГ 02", pady=18)
        c2.pack(fill="x", pady=(0, 12))
        for i in range(5):
            measure.columnconfigure(i, weight=1)
        self.temp_input = tk.StringVar()
        self.sys_input = tk.StringVar()
        self.dia_input = tk.StringVar()
        self.pulse_input = tk.StringVar()
        for i, (title, var) in enumerate((
            ("ТЕМПЕРАТУРА · °C", self.temp_input), ("АД ВЕРХНЕЕ", self.sys_input),
            ("АД НИЖНЕЕ", self.dia_input), ("ПУЛЬС · УД/МИН", self.pulse_input)
        )):
            field_label(measure, title).grid(row=0, column=i, sticky="w", pady=(0, 6))
            ttk.Entry(measure, textvariable=var, width=12).grid(row=1, column=i, sticky="ew", padx=(0, 12))
        button(measure, "+ Измерение", self.add_reading).grid(row=1, column=4, sticky="ew")
        self.measurement_tree = ttk.Treeview(measure, columns=("n", "time", "temp", "bp", "pulse"),
                                              show="headings", height=3)
        for col, title, width in (("n", "№", 48), ("time", "Время", 183),
                                   ("temp", "Темп. °C", 115), ("bp", "АД", 130),
                                   ("pulse", "Пульс", 102)):
            self.measurement_tree.heading(col, text=title)
            self.measurement_tree.column(col, width=width, stretch=True, anchor="w")
        self.measurement_tree.grid(row=2, column=0, columnspan=5, sticky="ew", pady=(13, 8))
        button(measure, "Удалить последнее", self.remove_last_reading, "ghost").grid(
            row=3, column=0, columnspan=2, sticky="w")
        label(measure, "Не более 2 повторов АД/пульса с интервалом 5–10 мин.", 9,
              color=MUTED).grid(row=3, column=2, columnspan=3, sticky="e")

        c3, tests = card(form, "Жалобы и исследования", "ШАГ 03", pady=18)
        c3.pack(fill="x", pady=(0, 12))
        tests.columnconfigure(0, weight=1)
        tests.columnconfigure(1, weight=1)
        field_label(tests, "ЖАЛОБЫ СОТРУДНИКА").grid(row=0, column=0, sticky="w", padx=(0, 15), pady=(0, 6))
        field_label(tests, "ВИЗУАЛЬНЫЙ ОСМОТР").grid(row=0, column=1, sticky="w", pady=(0, 6))
        self.complaints = entry_text(tests, height=3)
        self.complaints.grid(row=1, column=0, sticky="ew", padx=(0, 15))
        self.visual_notes = entry_text(tests, height=3)
        self.visual_notes.grid(row=1, column=1, sticky="ew")
        actions = tk.Frame(tests, bg=WHITE)
        actions.grid(row=2, column=0, columnspan=2, sticky="ew", pady=(12, 9))
        label(actions, "БЫСТРОЕ ЗАПОЛНЕНИЕ", 9, True, color=MUTED).pack(side="left")
        button(actions, "Жалоб нет", self.set_no_complaints, "subtle").pack(side="right")
        button(actions, "Осмотр без особенностей", self.set_normal_visual, "ghost").pack(
            side="right", padx=8)
        symptom_box = tk.Frame(tests, bg=WHITE)
        symptom_box.grid(row=3, column=0, columnspan=2, sticky="ew")
        label(symptom_box, "ОТМЕТИТЬ ЖАЛОБЫ (ЕСЛИ ЕСТЬ):", 9, True,
              color="#53675D").grid(row=0, column=0, columnspan=3,
                                     sticky="w", pady=(0, 7))
        self.symptom_vars = {}
        for index, name in enumerate(SYMPTOM_OPTIONS):
            variable = tk.BooleanVar(value=False)
            self.symptom_vars[name] = variable
            ttk.Checkbutton(symptom_box, text=name, variable=variable,
                            command=self.on_symptom_change).grid(
                                row=1 + index // 3, column=index % 3,
                                sticky="w", padx=(0, 23), pady=(0, 3))
        self.intoxication_assessment = tk.StringVar(value=SIGNS_OPTIONS[0])
        self.alcohol_level = tk.StringVar()
        self.alcohol_unit = tk.StringVar(value="мг/л")
        self.alcohol_result = tk.StringVar(value=ALCOHOL_RESULTS[0])
        self.drug_result = tk.StringVar(value=DRUG_RESULTS[0])
        field_label(tests, "ПРИЗНАКИ ОПЬЯНЕНИЯ").grid(row=4, column=0, sticky="w", pady=(16, 6))
        field_label(tests, "АЛКОТЕСТ · КОЛИЧЕСТВЕННЫЙ РЕЗУЛЬТАТ").grid(row=4, column=1, sticky="w", pady=(16, 6))
        ttk.Combobox(tests, textvariable=self.intoxication_assessment,
                     values=SIGNS_OPTIONS, state="readonly").grid(row=5, column=0, sticky="ew", padx=(0, 15))
        alcohol_box = tk.Frame(tests, bg=WHITE)
        alcohol_box.grid(row=5, column=1, sticky="ew")
        alcohol_box.columnconfigure(0, weight=1)
        ttk.Entry(alcohol_box, textvariable=self.alcohol_level).grid(row=0, column=0, sticky="ew", padx=(0, 8))
        ttk.Combobox(alcohol_box, textvariable=self.alcohol_unit, width=9,
                     values=("мг/л", "мкг/л"), state="readonly").grid(row=0, column=1)
        field_label(tests, "ОЦЕНКА АЛКОТЕСТА").grid(row=6, column=0, sticky="w", pady=(16, 6))
        field_label(tests, "ИССЛЕДОВАНИЕ МОЧИ (ПРИ ПОКАЗАНИЯХ)").grid(row=6, column=1, sticky="w", pady=(16, 6))
        ttk.Combobox(tests, textvariable=self.alcohol_result, values=ALCOHOL_RESULTS,
                     state="readonly").grid(row=7, column=0, sticky="ew", padx=(0, 15))
        ttk.Combobox(tests, textvariable=self.drug_result, values=DRUG_RESULTS,
                     state="readonly").grid(row=7, column=1, sticky="ew")
        label(tests, "Если есть признаки опьянения, а алкотест отрицательный — требуется исследование мочи.",
              9, color=MUTED).grid(row=8, column=0, columnspan=2, sticky="w", pady=(15, 0))

        c4, verdict = card(form, "Заключение медработника", "ШАГ 04", pady=18)
        c4.pack(fill="x", pady=(0, 14))
        verdict.columnconfigure(0, weight=1)
        verdict.columnconfigure(1, weight=2)
        self.conclusion = tk.StringVar(value="")
        self.nonadmit_reason = tk.StringVar()
        self.conclusion.trace_add("write", lambda *_: self.nonadmit_reason.set("")
                                  if self.conclusion.get() == "Допущен" else None)
        field_label(verdict, "РЕШЕНИЕ").grid(row=0, column=0, sticky="w", padx=(0, 14), pady=(0, 7))
        field_label(verdict, "ПРИЧИНА НЕДОПУСКА (ЕСЛИ ПРИМЕНИМО)").grid(row=0, column=1, sticky="w", pady=(0, 7))
        ttk.Combobox(verdict, textvariable=self.conclusion, state="readonly",
                     values=CONCLUSIONS).grid(row=1, column=0, sticky="ew", padx=(0, 14))
        ttk.Combobox(verdict, textvariable=self.nonadmit_reason, state="normal",
                     values=REASON_TEMPLATES).grid(row=1, column=1, sticky="ew")
        field_label(verdict, "КОММЕНТАРИЙ МЕДРАБОТНИКА").grid(row=2, column=0, columnspan=2,
                                                              sticky="w", pady=(15, 7))
        self.medical_comment = entry_text(verdict, height=2)
        self.medical_comment.grid(row=3, column=0, columnspan=2, sticky="ew")
        self.acknowledged = tk.BooleanVar(value=False)
        ttk.Checkbutton(verdict, variable=self.acknowledged,
                        text="Подтверждаю корректность ввода (не является электронной подписью)").grid(
                            row=4, column=0, columnspan=2, sticky="w", pady=(14, 0))
        bottom = tk.Frame(form, bg=BG)
        bottom.pack(fill="x", pady=(0, 25))
        button(bottom, "Сохранить в журнал  →", self.save_exam).pack(side="left")
        button(bottom, "Очистить форму", self.confirm_reset_form, "ghost").pack(side="left", padx=12)
        label(bottom, "Приказ Минздрава № 266н · проектный прототип", 9,
              color=MUTED, bg=BG).pack(side="right")

    def on_employee_selected(self, _event=None):
        selected_id = self.employee_lookup.get(self.employee_choice.get())
        if self.readings and self.reading_employee_id and selected_id != self.reading_employee_id:
            for title, eid in self.employee_lookup.items():
                if eid == self.reading_employee_id:
                    self.employee_choice.set(title)
                    break
            messagebox.showwarning("Измерения привязаны к работнику",
                                   "Измерения уже добавлены для другого сотрудника. "
                                   "Сначала очистите форму, если хотите сменить работника.", parent=self)
        self.update_employee_history()

    def update_employee_history(self):
        if not hasattr(self, "employee_history"):
            return
        employee_id = self.employee_lookup.get(self.employee_choice.get())
        if not employee_id:
            self.employee_history.configure(text="Последние осмотры: выберите сотрудника")
            return
        exams = self.store.employee_exams(employee_id, 3)
        if not exams:
            self.employee_history.configure(text="Последние осмотры: записей ещё нет")
        else:
            brief = "  •  ".join(f"{display_datetime(e['examined_at'])[:16]} — {e['conclusion']}"
                                  for e in exams)
            self.employee_history.configure(text="История (последние 3):  " + brief)

    def has_unsaved_form(self):
        """Check entered data (not just already added readings)."""
        values = (self.employee_choice.get(), self.temp_input.get(), self.sys_input.get(), self.dia_input.get(),
                  self.pulse_input.get(), self.alcohol_level.get(), self.nonadmit_reason.get())
        if self.readings or any(v.strip() for v in values):
            return True
        if any(v.get() for v in self.symptom_vars.values()):
            return True
        if any(widget.get("1.0", "end").strip() for widget in
               (self.complaints, self.visual_notes, self.medical_comment)):
            return True
        if self.nurse_name.get() != self._clean_nurse_name:
            return True
        if (self.exam_type.get() != EXAM_TYPES[0] or
                self.shift_label.get() != "Не указана" or
                self.intoxication_assessment.get() != SIGNS_OPTIONS[0] or
                self.alcohol_unit.get() != "мг/л" or
                self.alcohol_result.get() != ALCOHOL_RESULTS[0] or
                self.drug_result.get() != DRUG_RESULTS[0]):
            return True
        return self.acknowledged.get() or bool(self.conclusion.get())

    def confirm_reset_form(self):
        if self.has_unsaved_form() and not messagebox.askyesno(
                "Очистить форму", "Все несохранённые сведения об осмотре будут потеряны. Очистить?",
                parent=self):
            return
        self.reset_form()

    def close_app(self):
        if self.has_unsaved_form() and not messagebox.askyesno(
                "Закрыть программу", "В форме есть несохранённые данные. Закрыть программу без сохранения?",
                parent=self):
            return
        self._unbind_exam_scroll()
        self.destroy()

    def _bind_exam_scroll(self):
        # Used by the exam, overview and about pages.
        # A canvas <Leave> fires when the pointer moves over its child widgets,
        # so bindings tied only to the canvas make the form appear unscrollable.
        self.bind_all("<MouseWheel>", self._on_exam_wheel)
        self.bind_all("<Button-4>", self._on_exam_wheel)
        self.bind_all("<Button-5>", self._on_exam_wheel)

    def _unbind_exam_scroll(self):
        for sequence in ("<MouseWheel>", "<Button-4>", "<Button-5>"):
            self.unbind_all(sequence)

    def _on_exam_wheel(self, event):
        canvas = {"exam": self.exam_canvas,
                  "overview": self.overview_canvas,
                  "about": self.about_canvas}.get(self.page)
        if canvas is None:
            return
        try:
            if event.widget.winfo_toplevel() is not self:
                return  # Don't scroll behind a popup.
        except tk.TclError:
            return
        if isinstance(event.widget, (tk.Text, ttk.Combobox, ttk.Treeview)):
            return  # Let editable text and combo boxes handle their own wheel.
        if getattr(event, "num", None) == 4:
            delta = -2
        elif getattr(event, "num", None) == 5:
            delta = 2
        elif getattr(event, "delta", 0):
            delta = -1 if event.delta > 0 else 1
        else:
            return
        canvas.yview_scroll(delta, "units")

    def set_no_complaints(self):
        """Отдельное действие медработника: никаких значений не подставляем при открытии."""
        for variable in self.symptom_vars.values():
            variable.set(False)
        self.complaints.delete("1.0", "end")
        self.complaints.insert("1.0", "Жалоб нет")

    def set_normal_visual(self):
        self.visual_notes.delete("1.0", "end")
        self.visual_notes.insert("1.0", "Без особенностей")

    def on_symptom_change(self):
        if any(variable.get() for variable in self.symptom_vars.values()):
            if self.complaints.get("1.0", "end").strip().casefold() in ("жалоб нет", "нет жалоб"):
                self.complaints.delete("1.0", "end")

    def add_reading(self):
        selected_id = self.employee_lookup.get(self.employee_choice.get())
        if not selected_id:
            messagebox.showwarning("Сотрудник", "Сначала выберите сотрудника для измерения.", parent=self)
            return
        if self.readings and selected_id != self.reading_employee_id:
            messagebox.showwarning("Сотрудник", "Измерения относятся к другому сотруднику.", parent=self)
            return
        if len(self.readings) >= 3:
            messagebox.showwarning("Измерения", "Всего допускается первичное и два повторных измерения.", parent=self)
            return
        try:
            t = parse_float(self.temp_input.get(), "Температура", 25, 50) if self.temp_input.get().strip() else None
            if t is None and not self.readings:
                raise ValueError("Укажите температуру при первичном измерении.")
            systolic = parse_int(self.sys_input.get(), "АД верхнее", 30, 350)
            diastolic = parse_int(self.dia_input.get(), "АД нижнее", 20, 250)
            pulse = parse_int(self.pulse_input.get(), "Пульс", 15, 300)
            if systolic <= diastolic:
                raise ValueError("Верхнее давление должно превышать нижнее.")
            stamp = now_iso()
            if self.readings:
                prev = datetime.fromisoformat(self.readings[-1]["measured_at"])
                elapsed = (datetime.fromisoformat(stamp) - prev).total_seconds()
                if not 300 <= elapsed <= 600:
                    raise ValueError("Повторное измерение следует добавить через 5–10 минут. "
                                     f"Прошло {elapsed / 60:.1f} мин.")
        except ValueError as exc:
            messagebox.showerror("Проверка показателей", str(exc), parent=self)
            return
        if not self.readings:
            self.reading_employee_id = selected_id
        self.readings.append({"measured_at": stamp, "temperature": t,
                              "systolic": systolic, "diastolic": diastolic, "pulse": pulse})
        self.update_measurement_tree()
        for field in (self.temp_input, self.sys_input, self.dia_input, self.pulse_input):
            field.set("")

    def remove_last_reading(self):
        if self.readings:
            self.readings.pop()
            if not self.readings:
                self.reading_employee_id = None
            self.update_measurement_tree()

    def update_measurement_tree(self):
        self.measurement_tree.delete(*self.measurement_tree.get_children())
        for index, item in enumerate(self.readings, 1):
            self.measurement_tree.insert("", "end", values=(
                index, display_datetime(item["measured_at"]), format_number(item["temperature"]),
                f"{item['systolic']}/{item['diastolic']}", item["pulse"]))

    def save_exam(self):
        try:
            employee_id = self.employee_lookup.get(self.employee_choice.get())
            if not employee_id:
                raise ValueError("Выберите сотрудника. Если список пуст, добавьте его в справочнике.")
            if self.exam_type.get() not in EXAM_TYPES:
                raise ValueError("Выберите вид осмотра.")
            nurse = " ".join(self.nurse_name.get().split())
            if not nurse:
                raise ValueError("Введите ФИО медицинского работника.")
            if not self.readings:
                raise ValueError("Добавьте измерения температуры, давления и пульса.")
            if employee_id != self.reading_employee_id:
                raise ValueError("Измерения относятся к другому сотруднику. Проверьте выбор.")
            if any(var.get().strip() for var in
                   (self.temp_input, self.sys_input, self.dia_input, self.pulse_input)):
                raise ValueError("В полях измерений есть новые значения, которые ещё не добавлены. "
                                 "Нажмите «+ Измерение» или очистите эти поля.")
            alcohol = parse_float(self.alcohol_level.get(), "Алкотест", 0, 1000)
            if self.alcohol_result.get() not in ALCOHOL_RESULTS[1:]:
                raise ValueError("Укажите оценку алкотеста медработником.")
            complaints_note = self.complaints.get("1.0", "end").strip()
            complaint_tags = [name for name, var in self.symptom_vars.items() if var.get()]
            if complaint_tags and complaints_note.casefold() in ("жалоб нет", "нет жалоб"):
                raise ValueError("Отмечены жалобы, но написано «Жалоб нет». Уточните запись.")
            complaints = ("Отмечено: " + ", ".join(complaint_tags) +
                          (". Дополнительно: " + complaints_note if complaints_note else "")) if complaint_tags else complaints_note
            visual_notes = self.visual_notes.get("1.0", "end").strip()
            if not complaints:
                raise ValueError("Отметьте жалобы либо нажмите «Жалоб нет».")
            if not visual_notes:
                raise ValueError("Укажите результат визуального осмотра.")
            if self.intoxication_assessment.get() not in SIGNS_OPTIONS[1:]:
                raise ValueError("Укажите наличие или отсутствие признаков опьянения.")
            has_signs = self.intoxication_assessment.get() == "Выявлены"
            if self.drug_result.get() not in DRUG_RESULTS:
                raise ValueError("Укажите результат исследования мочи.")
            if (has_signs and self.alcohol_result.get() == "Отрицательный" and
                    self.drug_result.get() in DRUG_RESULTS[:2]):
                raise ValueError("При признаках опьянения и отрицательном алкотесте "
                                 "завершите предусмотренное исследование мочи.")
            decision = self.conclusion.get()
            if decision not in CONCLUSIONS:
                raise ValueError("Решение о допуске должен указать медработник.")
            reason = self.nonadmit_reason.get().strip()
            if decision == "Не допущен" and not reason:
                raise ValueError("Укажите причину недопуска.")
            if decision == "Допущен" and (has_signs or self.alcohol_result.get() == "Положительный" or
                                            self.drug_result.get() == "Положительный"):
                raise ValueError("Результаты исследования конфликтуют с допуском. "
                                 "Проверьте форму и заключение.")
            if not self.acknowledged.get():
                raise ValueError("Подтвердите правильность ввода в форме.")
            values = {"employee_id": employee_id, "exam_type": self.exam_type.get(),
                      "shift_label": self.shift_label.get(), "nurse_name": nurse,
                      "complaints": complaints, "complaint_tags": complaint_tags,
                      "visual_notes": visual_notes,
                      "intoxication_signs": has_signs, "alcohol_level": alcohol,
                      "alcohol_unit": self.alcohol_unit.get(),
                      "alcohol_result": self.alcohol_result.get(), "drug_result": self.drug_result.get(),
                      "conclusion": decision, "non_admission_reason": reason,
                      "medical_comment": self.medical_comment.get("1.0", "end").strip()}
            previous = self.store.same_day_exams(employee_id, self.exam_type.get(),
                                                 datetime.fromisoformat(self.readings[0]["measured_at"]).date().isoformat())
            if previous and not messagebox.askyesno(
                    "Повторная запись",
                    f"У сотрудника уже есть {len(previous)} осмотр(ов) такого типа за этот день.\n"
                    "Сохранить ещё один отдельный осмотр?", parent=self):
                return
            exam_id = self.store.create_exam(values, self.readings)
        except (ValueError, sqlite3.Error) as exc:
            messagebox.showerror("Запись не сохранена", str(exc), parent=self)
            return
        self.reset_form(keep_nurse=True)
        self.refresh_journal()
        self.refresh_dashboard()
        self.navigate("journal")
        self.open_exam_details(exam_id, saved=True)

    def reset_form(self, keep_nurse=False):
        self.employee_choice.set("")
        self.exam_type.set(EXAM_TYPES[0])
        self.shift_label.set("Не указана")
        if not keep_nurse:
            self.nurse_name.set("")
        self._clean_nurse_name = self.nurse_name.get()
        self.readings.clear()
        self.reading_employee_id = None
        self.update_measurement_tree()
        for var in (self.temp_input, self.sys_input, self.dia_input,
                    self.pulse_input, self.alcohol_level, self.nonadmit_reason):
            var.set("")
        self.alcohol_unit.set("мг/л")
        self.intoxication_assessment.set(SIGNS_OPTIONS[0])
        self.alcohol_result.set(ALCOHOL_RESULTS[0])
        self.drug_result.set(DRUG_RESULTS[0])
        self.conclusion.set("")
        self.acknowledged.set(False)
        for variable in self.symptom_vars.values():
            variable.set(False)
        for item in (self.complaints, self.visual_notes, self.medical_comment):
            item.delete("1.0", "end")
        self.update_employee_history()

    # -------------------------------- Journal --------------------------------
    def _build_journal_page(self):
        page = self._page("journal")
        outer = tk.Frame(page, bg=BG, padx=30, pady=23)
        outer.pack(fill="both", expand=True)
        top = tk.Frame(outer, bg=BG)
        top.pack(fill="x", pady=(0, 18))
        left = tk.Frame(top, bg=BG)
        left.pack(side="left")
        label(left, "Журнал медицинских осмотров", 17, True, bg=BG).pack(anchor="w")
        self.journal_count = label(left, "Записей: 0", 9, color=MUTED, bg=BG)
        self.journal_count.pack(anchor="w", pady=(3, 0))
        button(top, "Экспорт CSV  ↗", self.export_csv, "ghost").pack(side="right")
        button(top, "Копия БД", self.backup_db, "ghost").pack(side="right", padx=9)
        button(top, "Проверить БД", self.check_database, "subtle").pack(side="right")
        filters, inner = card(outer, pady=14)
        filters.pack(fill="x", pady=(0, 13))
        filter_bar = tk.Frame(inner, bg=WHITE)
        filter_bar.pack(fill="x")
        field_label(filter_bar, "ПОИСК: ФИО, ТАБЕЛЬНЫЙ №, ЦЕХ ИЛИ ДОЛЖНОСТЬ").pack(anchor="w", pady=(0, 8))
        self.search_var = tk.StringVar()
        se = ttk.Entry(filter_bar, textvariable=self.search_var)
        se.pack(side="left", fill="x", expand=True, padx=(0, 10))
        self.search_var.trace_add("write", lambda *_: self.refresh_journal())
        self.journal_result = tk.StringVar(value="Все результаты")
        result_filter = ttk.Combobox(filter_bar, state="readonly", width=18,
                                     values=("Все результаты", "Допущен", "Не допущен"),
                                     textvariable=self.journal_result)
        result_filter.pack(side="left", padx=(0, 10))
        result_filter.bind("<<ComboboxSelected>>", lambda _: self.refresh_journal())
        self.journal_period = tk.StringVar(value="Все")
        period_filter = ttk.Combobox(filter_bar, state="readonly", width=12,
                                     values=("Все", "Сегодня", "7 дней"),
                                     textvariable=self.journal_period)
        period_filter.pack(side="left", padx=(0, 10))
        period_filter.bind("<<ComboboxSelected>>", lambda _: self.refresh_journal())
        button(filter_bar, "Очистить", self.clear_journal_filter, "subtle").pack(side="left")
        tbl_outer, tbl = card(outer, pady=14)
        tbl_outer.pack(fill="both", expand=True)
        wrapper = tk.Frame(tbl, bg=WHITE)
        wrapper.pack(fill="both", expand=True)
        cols = ("id", "when", "employee", "department", "shift", "kind", "temp", "bp", "pulse", "result")
        self.journal_tree = ttk.Treeview(wrapper, columns=cols, show="headings", selectmode="browse")
        for col, title, width in (("id", "№", 44), ("when", "Дата / время", 157),
                                   ("employee", "Сотрудник", 210), ("department", "Цех", 130),
                                   ("shift", "Смена", 110), ("kind", "Осмотр", 115),
                                   ("temp", "°C", 54), ("bp", "АД", 86),
                                   ("pulse", "Пульс", 63), ("result", "Решение", 125)):
            self.journal_tree.heading(col, text=title)
            self.journal_tree.column(col, width=width, anchor="w", stretch=(col == "employee"))
        sbv = ttk.Scrollbar(wrapper, orient="vertical", command=self.journal_tree.yview)
        sbh = ttk.Scrollbar(tbl, orient="horizontal", command=self.journal_tree.xview)
        self.journal_tree.configure(yscrollcommand=sbv.set, xscrollcommand=sbh.set)
        self.journal_tree.pack(side="left", fill="both", expand=True)
        sbv.pack(side="right", fill="y")
        sbh.pack(fill="x")
        self.journal_tree.tag_configure("admitted", background="#F2FAF3")
        self.journal_tree.tag_configure("refused", background="#FFF0EF")
        self.journal_tree.bind("<Double-1>", lambda _: self.show_exam_details())
        bar = tk.Frame(outer, bg=BG)
        bar.pack(fill="x", pady=(12, 0))
        label(bar, "Двойной щелчок по записи — подробности и история измерений",
              9, color=MUTED, bg=BG).pack(side="left", pady=10)
        button(bar, "Открыть запись  →", self.show_exam_details).pack(side="right")

    def refresh_journal(self):
        if not hasattr(self, "journal_tree"):
            return
        exams = self.store.list_exams(self.search_var.get(), self.journal_period.get())
        status = self.journal_result.get()
        if status in CONCLUSIONS:
            exams = [e for e in exams if e["conclusion"] == status]
        self.journal_tree.delete(*self.journal_tree.get_children())
        for e in exams:
            self.journal_tree.insert("", "end", iid=str(e["id"]), values=(
                e["id"], display_datetime(e["examined_at"])[:16], e["employee_name"],
                e["employee_department"] or "—", e["shift_label"] or "—", e["exam_type"],
                format_number(e["last_temperature"]),
                f"{e['last_systolic']}/{e['last_diastolic']}", e["last_pulse"], e["conclusion"]),
                tags=("admitted" if e["conclusion"] == "Допущен" else "refused",))
        self.journal_count.configure(text=f"Записей найдено: {len(exams)}")

    def clear_journal_filter(self):
        self.search_var.set("")
        self.journal_result.set("Все результаты")
        self.journal_period.set("Все")
        self.refresh_journal()

    def show_exam_details(self):
        selection = self.journal_tree.selection()
        if not selection:
            messagebox.showinfo("Журнал", "Выберите запись в таблице.", parent=self)
            return
        self.open_exam_details(int(selection[0]))

    def open_exam_details(self, exam_id, saved=False):
        exam, readings = self.store.get_exam(exam_id)
        if not exam:
            return
        window = tk.Toplevel(self)
        window.title(f"Осмотр № {exam_id} · АЗОТ")
        details_w = min(845, max(600, self.winfo_screenwidth() - 70))
        details_h = min(665, max(470, self.winfo_screenheight() - 100))
        window.geometry(f"{details_w}x{details_h}")
        window.minsize(min(640, details_w), min(490, details_h))
        window.configure(bg=BG)
        window.transient(self)
        titlebar = tk.Frame(window, bg=GREEN_LIGHT if exam["conclusion"] == "Допущен" else RED_LIGHT,
                            padx=24, pady=17)
        titlebar.pack(fill="x")
        label(titlebar, "ОСМОТР № " + str(exam_id) + ("  ·  СОХРАНЕНО" if saved else ""),
              10, True, GREEN_DARK if exam["conclusion"] == "Допущен" else RED,
              titlebar["bg"]).pack(anchor="w")
        label(titlebar, exam["conclusion"].upper(), 22, True,
              GREEN_DARK if exam["conclusion"] == "Допущен" else RED,
              titlebar["bg"]).pack(anchor="w", pady=(5, 0))
        lines = [
            f"Дата осмотра:       {display_datetime(exam['examined_at'])}",
            f"Вид осмотра:        {exam['exam_type']}",
            f"Табельный номер:    {exam['personnel_number']}",
            f"Сотрудник:         {exam['employee_name']}",
            f"Цех / участок:     {exam['employee_department'] or '—'}",
            f"Должность:         {exam['employee_position'] or '—'}",
            f"Смена:             {exam['shift_label'] or '—'}",
            f"Пол: {exam['employee_sex']}   ·   Дата рождения: {display_date(exam['employee_birth_date'])}",
            f"Медработник:       {exam['nurse_name']}", "",
            "ИЗМЕРЕНИЯ", "────────────────────────────────────────────────────────────────────",
        ]
        for r in readings:
            lines.append(f"№{r['attempt_no']}   {display_datetime(r['measured_at'])}   "
                         f"T: {format_number(r['temperature'])} °C   "
                         f"АД: {r['systolic']}/{r['diastolic']}   Пульс: {r['pulse']}")
        lines += ["", "ОСМОТР И ИССЛЕДОВАНИЯ", "────────────────────────────────────────────────────────────────────",
                  "Жалобы: " + exam["complaints"],
                  "Отмеченные жалобы: " + (", ".join(decode_symptoms(exam["complaint_tags"])) or "—"),
                  "Визуальный осмотр: " + exam["visual_notes"],
                  "Признаки опьянения: " + ("Выявлены" if exam["intoxication_signs"] else "Не выявлены"),
                  f"Алкотест: {format_number(exam['alcohol_level'])} {exam['alcohol_unit']} "
                  f"({exam['alcohol_result']})",
                  "Исследование мочи: " + exam["drug_result"], "",
                  "ЗАКЛЮЧЕНИЕ", "────────────────────────────────────────────────────────────────────",
                  "Решение: " + exam["conclusion"],
                  "Причина недопуска: " + (exam["non_admission_reason"] or "—"),
                  "Комментарий: " + (exam["medical_comment"] or "—"), "",
                  "ПОДТВЕРЖДЕНИЕ И БЕЗОПАСНОСТЬ", "────────────────────────────────────────────────────────────────────",
                  "Подтверждение ввода: " + display_datetime(exam["acknowledged_at"]),
                  "Электронной подписи нет. Только демонстрационный прототип."]
        frame = tk.Frame(window, bg=WHITE, padx=22, pady=15)
        frame.pack(fill="both", expand=True, padx=20, pady=17)
        scroll = ttk.Scrollbar(frame)
        scroll.pack(side="right", fill="y")
        out = tk.Text(frame, font=("Consolas", 10), bg=WHITE, fg=TEXT, relief="flat", bd=0,
                      wrap="word", padx=5, pady=5, yscrollcommand=scroll.set)
        out.pack(fill="both", expand=True)
        scroll.configure(command=out.yview)
        out.insert("1.0", "\n".join(lines))
        out.configure(state="disabled")
        button(window, "Закрыть", window.destroy).pack(side="right", padx=25, pady=(0, 16))
        window.bind("<Escape>", lambda _: window.destroy())

    def export_csv(self):
        rows = self.store.list_exams(self.search_var.get(), self.journal_period.get())
        if self.journal_result.get() in CONCLUSIONS:
            rows = [e for e in rows if e["conclusion"] == self.journal_result.get()]
        if not rows:
            messagebox.showinfo("Экспорт", "Записей для экспорта нет.", parent=self)
            return
        if not messagebox.askyesno("Предупреждение о персональных данных",
                                   "CSV содержит персональные и медицинские данные БЕЗ шифрования.\n"
                                   "Экспортировать демонстрационные данные?", parent=self):
            return
        try:
            export_dir = self._output_dir("exports")
            export_dir.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            messagebox.showerror("Экспорт", f"Папка для экспорта недоступна: {exc}", parent=self)
            return
        dest = filedialog.asksaveasfilename(parent=self, title="Сохранить CSV", initialdir=str(export_dir),
                                            initialfile=f"azot_journal_{datetime.now():%Y%m%d_%H%M%S}.csv",
                                            defaultextension=".csv", filetypes=[("CSV для Excel", "*.csv")])
        if not dest:
            return
        columns = ["№", "Дата/время", "Вид", "Табельный №", "ФИО", "Цех", "Должность", "Смена",
                   "Пол", "Дата рождения", "Медработник", "Измерения", "Жалобы", "Отмеченные жалобы",
                   "Визуальный осмотр", "Признаки опьянения",
                   "Алкотест число", "Алкотест единицы", "Оценка алкотеста", "Исследование мочи",
                   "Заключение", "Причина недопуска", "Комментарий", "Время сохранения"]
        # Write to a sibling temporary file first. A full disk, failed CSV
        # generation or a failed replace must not corrupt an earlier export.
        temp_name = None
        try:
            fd, temp_name = tempfile.mkstemp(prefix=".azot_export_", suffix=".csv",
                                             dir=Path(dest).parent)
            with os.fdopen(fd, "w", encoding="utf-8-sig", newline="") as fh:
                writer = csv.writer(fh, delimiter=";")
                writer.writerow(columns)
                for e in rows:
                    _, readings = self.store.get_exam(e["id"])
                    measured = " | ".join(
                        f"№{r['attempt_no']} {display_datetime(r['measured_at'])}: "
                        f"T={format_number(r['temperature'])}, АД={r['systolic']}/{r['diastolic']}, "
                        f"пульс={r['pulse']}" for r in readings)
                    values = [e["id"], display_datetime(e["examined_at"]), e["exam_type"],
                              e["personnel_number"], e["employee_name"], e["employee_department"],
                              e["employee_position"], e["shift_label"], e["employee_sex"],
                              display_date(e["employee_birth_date"]), e["nurse_name"], measured,
                              e["complaints"], ", ".join(decode_symptoms(e["complaint_tags"])),
                              e["visual_notes"],
                              "Да" if e["intoxication_signs"] else "Нет", format_number(e["alcohol_level"]),
                              e["alcohol_unit"], e["alcohol_result"], e["drug_result"],
                              e["conclusion"], e["non_admission_reason"], e["medical_comment"],
                              display_datetime(e["saved_at"])]
                    writer.writerow([safe_csv_cell(v) for v in values])
                fh.flush()
                os.fsync(fh.fileno())
            os.replace(temp_name, dest)
            temp_name = None
        except (OSError, sqlite3.Error) as exc:
            messagebox.showerror("Экспорт", str(exc), parent=self)
            return
        finally:
            if temp_name is not None:
                Path(temp_name).unlink(missing_ok=True)
        # The export is already complete even if the optional audit fails.
        try:
            self.store.audit_event("CSV_EXPORT", f"CSV: {Path(dest).name} ({len(rows)} записей)")
        except (OSError, sqlite3.Error):
            pass
        messagebox.showinfo("CSV экспортирован", f"Записей: {len(rows)}\n{dest}", parent=self)

    def check_database(self):
        try:
            healthy, report = self.store.check_integrity()
        except (sqlite3.Error, OSError) as exc:
            messagebox.showerror("Проверка базы", f"Проверка не выполнена: {exc}", parent=self)
            return
        if healthy:
            messagebox.showinfo("Проверка базы", report + "\n\nЭто не медицинская и не юридическая проверка.",
                                parent=self)
        else:
            messagebox.showwarning("Обнаружены проблемы", report + "\nСделайте копию и обратитесь к администратору.",
                                   parent=self)

    def backup_db(self):
        if not messagebox.askyesno("Резервная копия",
                                   "Копия SQLite будет НЕ зашифрована.\n"
                                   "Создать копию локальной демонстрационной базы?", parent=self):
            return
        try:
            backup_dir = self._output_dir("backups")
            backup_dir.mkdir(parents=True, exist_ok=True)
            dest = backup_dir / f"azot_medcontrol_{datetime.now():%Y%m%d_%H%M%S_%f}.sqlite3"
            self.store.backup(dest)
        except (OSError, sqlite3.Error) as exc:
            messagebox.showerror("Копирование", str(exc), parent=self)
            return
        messagebox.showinfo("Копия создана", str(dest), parent=self)

    # ------------------------------ About / UML -----------------------------
    def _build_about_page(self):
        page = self._page("about")
        viewport = tk.Frame(page, bg=BG)
        viewport.pack(fill="both", expand=True)
        self.about_canvas = tk.Canvas(viewport, bg=BG, highlightthickness=0, bd=0)
        scrollbar = ttk.Scrollbar(viewport, orient="vertical", command=self.about_canvas.yview)
        self.about_canvas.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side="right", fill="y")
        self.about_canvas.pack(side="left", fill="both", expand=True)
        wrapper = tk.Frame(self.about_canvas, bg=BG, padx=30, pady=23)
        window_id = self.about_canvas.create_window((0, 0), anchor="nw", window=wrapper)
        wrapper.bind("<Configure>", lambda _: self.about_canvas.configure(
            scrollregion=self.about_canvas.bbox("all")))
        self.about_canvas.bind("<Configure>", lambda e: self.about_canvas.itemconfigure(
            window_id, width=e.width))
        head, inside = card(wrapper, "АЗОТ / МЕДКОНТРОЛЬ", "ДЕМО-КОНЦЕПЦИЯ · ВЕРСИЯ 4.5", pady=22)
        head.pack(fill="x", pady=(0, 16))
        label(inside, "Настольная программа для моделирования предсменных и предрейсовых медосмотров.",
              11, color=MUTED).pack(anchor="w")
        label(inside, "Вдохновлено цветовой гаммой КАО «Азот» (Кемерово). "
              "Демонстрационный дизайн, неофициальный продукт предприятия.",
              10, color=MUTED, wraplength=790, justify="left").pack(anchor="w", pady=(10, 0))
        label(inside, f"Локальная база: {self.store.db_path}",
              9, color=MUTED, wraplength=790, justify="left").pack(anchor="w", pady=(8, 0))
        boxes = tk.Frame(wrapper, bg=BG)
        boxes.pack(fill="both", expand=True)
        boxes.columnconfigure(0, weight=1)
        boxes.columnconfigure(1, weight=1)
        boxes.rowconfigure(0, weight=1)
        left_outer, left = card(boxes, "Структура приложения", pady=22)
        left_outer.grid(row=0, column=0, sticky="nsew", padx=(0, 8))
        for title, desc in (("Интерфейс · Tkinter", "Вкладки, формы, поиск, решения"),
                            ("Хранилище · SQLite", "Сотрудники, осмотры, измерения, события"),
                            ("Экспорт · CSV", "Отчёт с фильтрами по периоду"),
                            ("Проверка БД", "Контроль целостности SQLite"),
                            ("Windows · start.bat", "Запуск двойным кликом")):
            label(left, title, 11, True).pack(anchor="w", pady=(8, 2))
            label(left, desc, 9, color=MUTED).pack(anchor="w")
        button(left, "Открыть UML-диаграмму  ↗", self.open_uml).pack(anchor="w", pady=(18, 0))
        right_outer, right = card(boxes, "Ограничения прототипа", pady=22)
        right_outer.grid(row=0, column=1, sticky="nsew")
        for notice in (
            "Нет электронной подписи и юридического журнала",
            "Нет авторизации и разграничения ролей",
            "Нет шифрования базы и резервных копий",
            "Не используется для реальных допусков",
            "Нет интеграции с приборами и СКУД",
        ):
            label(right, "•  " + notice, 10, color=TEXT, wraplength=350,
                  justify="left").pack(anchor="w", pady=7)
        line(right).pack(fill="x", pady=15)
        label(right, "Для запуска на рабочем месте сначала согласуйте требования "
              "с медицинской службой и специалистами по ИБ.", 9,
              color=MUTED, wraplength=360, justify="left").pack(anchor="w")

    def open_uml(self):
        path = ROOT / "UML_medcontrol.svg"
        if not path.exists():
            messagebox.showwarning("UML", "Файл схемы не найден рядом с программой.", parent=self)
            return
        try:
            webbrowser.open(path.resolve().as_uri())
        except Exception as exc:
            messagebox.showerror("UML", str(exc), parent=self)


def main():
    app = App()
    app.mainloop()


if __name__ == "__main__":
    main()
