"""Small Tkinter smoke tests; headless systems skip unless started with xvfb-run."""
import tempfile
import tkinter as tk
import unittest
from types import SimpleNamespace
from pathlib import Path
from unittest.mock import patch

from app import App, EmployeeDialog, decode_symptoms
from database import Store


class UITests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.store = Store(Path(self.tmp.name) / "ui.sqlite3")
        self.eid = self.store.save_employee("T-88", "Демо Работник", "02.02.1991", "М")
        try:
            self.app = App(self.store)
            self.app.withdraw()
            self.app.refresh_employee_choices()
        except tk.TclError as exc:
            self.tmp.cleanup()
            self.skipTest(f"Tk дисплей недоступен: {exc}")

    def tearDown(self):
        if hasattr(self, "app"):
            self.app.destroy()
        self.tmp.cleanup()

    def enter_valid_exam(self):
        self.app.employee_choice.set(next(iter(self.app.employee_lookup)))
        self.app.on_employee_selected()
        self.app.nurse_name.set("Тестовая Медсестра")
        self.app.temp_input.set("36,6")
        self.app.sys_input.set("120")
        self.app.dia_input.set("80")
        self.app.pulse_input.set("75")
        self.app.add_reading()
        self.app.set_no_complaints()
        self.app.set_normal_visual()
        self.app.intoxication_assessment.set("Не выявлены")
        self.app.alcohol_level.set("0")
        self.app.alcohol_result.set("Отрицательный")
        self.app.conclusion.set("Допущен")
        self.app.acknowledged.set(True)

    def test_add_and_save_through_window(self):
        self.enter_valid_exam()
        with patch.object(self.app, "open_exam_details"):
            self.app.save_exam()
        self.assertEqual(len(self.store.list_exams()), 1)
        self.assertEqual(self.store.list_exams()[0]["last_pulse"], 75)

    def test_unadded_reading_must_not_be_discarded(self):
        self.enter_valid_exam()
        self.app.pulse_input.set("81")
        with patch("app.messagebox.showerror") as error:
            self.app.save_exam()
        error.assert_called_once()
        self.assertIn("ещё не добавлены", error.call_args.args[1])
        self.assertEqual(len(self.store.list_exams()), 0)

    def test_confirmation_before_losing_work(self):
        self.enter_valid_exam()
        with patch("app.messagebox.askyesno", return_value=False):
            self.app.confirm_reset_form()
        self.assertEqual(len(self.app.readings), 1)
        with patch("app.messagebox.askyesno", return_value=True):
            self.app.confirm_reset_form()
        self.assertFalse(self.app.readings)
        self.assertFalse(self.app.has_unsaved_form())

    def test_select_another_employee_is_blocked_with_readings(self):
        other = self.store.save_employee("T-89", "Другой Работник", "01.05.1987", "М")
        self.app.refresh_employee_choices()
        self.enter_valid_exam()
        selection = next(k for k, v in self.app.employee_lookup.items() if v == other)
        self.app.employee_choice.set(selection)
        with patch("app.messagebox.showwarning") as warning:
            self.app.on_employee_selected()
        self.assertEqual(warning.call_count, 1)
        self.assertEqual(self.app.employee_lookup[self.app.employee_choice.get()], self.eid)

    def test_duplicate_same_day_warns_before_save(self):
        self.enter_valid_exam()
        with patch.object(self.app, "open_exam_details"):
            self.app.save_exam()
        self.assertEqual(len(self.store.list_exams()), 1)
        self.enter_valid_exam()
        with patch("app.messagebox.askyesno", return_value=False) as warning:
            self.app.save_exam()
        warning.assert_called_once()
        self.assertEqual(len(self.store.list_exams()), 1)

    def test_check_integrity_button(self):
        with patch("app.messagebox.showinfo") as info:
            self.app.check_database()
        self.assertIn("ошибок целостности", info.call_args.args[1])

    def test_employee_dialog_has_room_for_save_button(self):
        dialog = EmployeeDialog(self.app)
        self.app.update_idletasks()
        self.assertGreaterEqual(dialog.winfo_height(), dialog.winfo_reqheight())
        dialog.destroy()

    def test_exam_wheel_scrolls_over_child_labels(self):
        self.app.deiconify()
        self.app.navigate("exam")
        self.app.update_idletasks()
        self.app.exam_canvas.yview_moveto(0)
        self.app._on_exam_wheel(SimpleNamespace(widget=self.app.employee_history,
                                                 delta=-120, num=None))
        self.assertGreater(self.app.exam_canvas.yview()[0], 0)
        before = self.app.exam_canvas.yview()
        self.app._on_exam_wheel(SimpleNamespace(widget=self.app.complaints,
                                                 delta=-120, num=None))
        self.assertEqual(self.app.exam_canvas.yview(), before)

    def test_bad_legacy_symptoms_do_not_crash(self):
        self.assertEqual(decode_symptoms("{not-json"), [])
        self.assertEqual(decode_symptoms('["Слабость"]'), ["Слабость"])


if __name__ == "__main__":
    unittest.main()
