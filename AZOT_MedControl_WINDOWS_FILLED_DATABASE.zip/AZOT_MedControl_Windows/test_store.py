"""Независимые тесты SQLite-хранилища. Запуск: python -m unittest test_store.py"""
import tempfile
import unittest
import sqlite3
from contextlib import closing
from datetime import datetime, timedelta
from pathlib import Path

from database import Store, now_iso


class StorageTests(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.db = Store(Path(self.temp_dir.name) / "sandbox.sqlite3")
        self.eid = self.db.save_employee("AZ-001", "Тестовый Работник", "01.01.1991", "М",
                                         department="Цех № 5", position="Аппаратчик")

    def tearDown(self):
        self.temp_dir.cleanup()

    def sample_details(self):
        return dict(employee_id=self.eid, exam_type="Предсменный", shift_label="Дневная",
                    nurse_name="Медработник Тест", complaints="Жалоб нет", complaint_tags=[],
                    visual_notes="Без особенностей",
                    intoxication_signs=False, alcohol_level=0.0, alcohol_unit="мг/л",
                    alcohol_result="Отрицательный", drug_result="Не требовалось",
                    conclusion="Допущен", non_admission_reason="", medical_comment="")

    def test_insert_exam_with_repeat_and_backup(self):
        stamp = datetime.now().astimezone() - timedelta(minutes=7)
        r1 = dict(measured_at=stamp.isoformat(timespec="seconds"), temperature=36.6,
                  systolic=130, diastolic=84, pulse=88)
        r2 = dict(measured_at=(stamp + timedelta(minutes=7)).isoformat(timespec="seconds"),
                  temperature=None, systolic=120, diastolic=80, pulse=75)
        exam_id = self.db.create_exam(self.sample_details(), [r1, r2])
        exam, measurements = self.db.get_exam(exam_id)
        self.assertEqual(exam["employee_name"], "Тестовый Работник")
        self.assertEqual(exam["employee_department"], "Цех № 5")
        self.assertEqual(exam["employee_position"], "Аппаратчик")
        self.assertEqual(exam["shift_label"], "Дневная")
        self.assertEqual(exam["conclusion"], "Допущен")
        self.assertEqual(len(measurements), 2)
        self.assertEqual(measurements[1]["pulse"], 75)
        self.assertEqual(self.db.list_exams("AZ-001")[0]["readings_count"], 2)
        dest = Path(self.temp_dir.name) / "backup.sqlite3"
        self.db.backup(dest)
        self.assertTrue(dest.exists())
        self.assertEqual(Store(dest).get_exam(exam_id)[0]["id"], exam_id)

    def test_duplicate_personnel_number_is_rejected(self):
        with self.assertRaisesRegex(ValueError, "табельный номер"):
            self.db.save_employee("AZ-001", "Ещё Один", "01.01.1991", "М")

    def test_exam_requires_measurement(self):
        with self.assertRaisesRegex(ValueError, "измерение"):
            self.db.create_exam(self.sample_details(), [])

    def test_symptom_tags_are_recorded(self):
        data = self.sample_details()
        data.update(complaints="Отмечено: Головная боль", complaint_tags=["Головная боль"],
                    conclusion="Не допущен", non_admission_reason="Жалобы на самочувствие")
        exam_id = self.db.create_exam(data, [dict(measured_at=now_iso(), temperature=36.7,
                                                  systolic=125, diastolic=82, pulse=85)])
        exam, _ = self.db.get_exam(exam_id)
        self.assertEqual(exam["complaint_tags"], '["Головная боль"]')
        self.assertEqual(self.db.list_exams("Цех № 5")[0]["id"], exam_id)

    def test_migration_from_old_database_keeps_employee(self):
        legacy_path = Path(self.temp_dir.name) / "legacy.sqlite3"
        with closing(sqlite3.connect(legacy_path)) as old, old:
            old.executescript("""
                CREATE TABLE employees (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    personnel_number TEXT NOT NULL UNIQUE,
                    full_name TEXT NOT NULL, birth_date TEXT NOT NULL,
                    sex TEXT NOT NULL, created_at TEXT NOT NULL);
                CREATE TABLE medical_exams (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    employee_id INTEGER NOT NULL, personnel_number TEXT NOT NULL,
                    employee_name TEXT NOT NULL, employee_birth_date TEXT NOT NULL,
                    employee_sex TEXT NOT NULL, exam_type TEXT NOT NULL,
                    examined_at TEXT NOT NULL, saved_at TEXT NOT NULL,
                    nurse_name TEXT NOT NULL, complaints TEXT NOT NULL,
                    visual_notes TEXT NOT NULL, intoxication_signs INTEGER NOT NULL,
                    alcohol_level REAL NOT NULL, alcohol_unit TEXT NOT NULL,
                    alcohol_result TEXT NOT NULL, drug_result TEXT NOT NULL,
                    conclusion TEXT NOT NULL, non_admission_reason TEXT NOT NULL,
                    medical_comment TEXT NOT NULL, acknowledged_at TEXT NOT NULL);
            """)
            old.execute("""INSERT INTO employees
                          (personnel_number,full_name,birth_date,sex,created_at)
                          VALUES(?,?,?,?,?)""", ("OLD-1", "Сотрудник Старой Версии",
                                                  "1990-01-01", "Ж", now_iso()))
            old.execute("""INSERT INTO medical_exams (
                employee_id,personnel_number,employee_name,employee_birth_date,employee_sex,
                exam_type,examined_at,saved_at,nurse_name,complaints,visual_notes,
                intoxication_signs,alcohol_level,alcohol_unit,alcohol_result,drug_result,
                conclusion,non_admission_reason,medical_comment,acknowledged_at
            ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (1, "OLD-1", "Сотрудник Старой Версии", "1990-01-01", "Ж",
                 "Предсменный", now_iso(), now_iso(), "Тест Медсестра",
                 "Жалоб нет", "Без особенностей", 0, 0.0, "мг/л",
                 "Отрицательный", "Не требовалось", "Допущен", "", "", now_iso()))
        restored = Store(legacy_path)
        employee = restored.list_employees()[0]
        self.assertEqual(employee["full_name"], "Сотрудник Старой Версии")
        self.assertEqual(employee["department"], "")
        restored.save_employee("OLD-1", employee["full_name"], "01.01.1990", "Ж",
                               employee_id=employee["id"], department="Цех № 1",
                               position="Контролёр")
        self.assertEqual(restored.list_employees()[0]["department"], "Цех № 1")
        old_exam, _ = restored.get_exam(1)
        self.assertEqual(old_exam["conclusion"], "Допущен")
        self.assertEqual(old_exam["complaint_tags"], "[]")


if __name__ == "__main__":
    unittest.main()
