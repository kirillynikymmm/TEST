"""Regression tests for fixes in v4.1: Unicode, backup, malformed legacy data."""
import sqlite3
import tempfile
import unittest
from datetime import datetime
from pathlib import Path
from unittest.mock import patch

from database import Store, format_number, now_iso


class ReliabilityTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.dbfile = Path(self.temp.name) / "test.sqlite3"
        self.db = Store(self.dbfile)
        self.eid = self.db.save_employee(
            "А-23", "Петрова Марина Игоревна", "11.01.1990", "Ж",
            department="Цех № 17", position="Аппаратчик")

    def tearDown(self):
        self.temp.cleanup()

    def demo_exam(self):
        return self.db.create_exam({
            "employee_id": self.eid, "exam_type": "Предсменный", "shift_label": "Дневная",
            "nurse_name": "Сидорова", "complaints": "Жалоб нет", "complaint_tags": [],
            "visual_notes": "Без особенностей", "intoxication_signs": False,
            "alcohol_level": "0", "alcohol_unit": "мг/л", "alcohol_result": "Отрицательный",
            "drug_result": "Не требовалось", "conclusion": "Допущен",
            "non_admission_reason": "", "medical_comment": ""
        }, [{"measured_at": now_iso(), "temperature": 36.5,
             "systolic": 120, "diastolic": 80, "pulse": 72}])

    def test_cyrillic_journal_search_is_case_insensitive(self):
        exam_id = self.demo_exam()
        for term in ("петрова", "ПЕТРОВА", "ПеТрОвА", "аппаратчик",
                     "АППАРАТЧИК", "цЕх № 17", "а-23"):
            with self.subTest(term=term):
                self.assertEqual([r['id'] for r in self.db.list_exams(term)], [exam_id])
        self.assertEqual(self.db.list_exams("Петр%"), [])
        self.assertEqual(self.db.list_exams("Петро_а"), [])

    def test_alcohol_level_stored_as_number(self):
        eid = self.demo_exam()
        row, _ = self.db.get_exam(eid)
        self.assertEqual(row["alcohol_level"], 0.0)
        self.assertEqual(self.db.list_exams("петрова")[0]["id"], eid)

    def test_backup_is_atomic_when_replace_fails(self):
        self.demo_exam()
        dest = Path(self.temp.name) / "backup.sqlite3"
        dest.write_bytes(b"OLD BACKUP MUST NOT BE OVERWRITTEN")
        with patch("database.os.replace", side_effect=OSError("simulated interrupted write")):
            with self.assertRaisesRegex(OSError, "simulated"):
                self.db.backup(dest)
        self.assertEqual(dest.read_bytes(), b"OLD BACKUP MUST NOT BE OVERWRITTEN")
        self.assertEqual(list(Path(self.temp.name).glob(".medcontrol_backup_*")), [])
        self.db.backup(dest)
        self.assertEqual(len(Store(dest).list_exams()), 1)

    def test_bad_data_cannot_crash_journal_format(self):
        for value in (None, "not a number", "nan", "Infinity", float("inf")):
            with self.subTest(value=value):
                self.assertEqual(format_number(value), "—")
        self.assertEqual(format_number("36,6"), "36.6")

    def test_bad_payload_returns_clear_validation_error(self):
        with self.assertRaisesRegex(ValueError, "сотрудника"):
            self.db.create_exam({"employee_id": None}, [])
        with self.assertRaisesRegex(ValueError, "формат измерений"):
            self.db.create_exam({"employee_id": self.eid}, "invalid")


if __name__ == "__main__":
    unittest.main()
