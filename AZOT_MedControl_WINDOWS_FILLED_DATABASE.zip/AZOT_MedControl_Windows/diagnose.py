"""Offline Windows self-check. Does not open or alter employee/exam data.

Run with ``start.bat /check`` or double-click ``check_windows.bat``.
Only diagnostic text is stored; no medical data is exported.
"""
from __future__ import annotations

import platform
import sqlite3
import sys
import tempfile
import traceback
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def run_diagnostics() -> int:
    lines: list[str] = [
        "AZOT MedControl — диагностика запуска",
        f"Проверка: {datetime.now().astimezone().isoformat(timespec='seconds')}",
        f"ОС: {platform.platform()}",
        f"Python: {sys.version.split()[0]} ({sys.executable})",
        f"Папка программы: {ROOT}",
        "",
    ]
    good = True

    def record(ok: bool, name: str, detail: str = "") -> None:
        nonlocal good
        good &= ok
        lines.append(("[OK] " if ok else "[ОШИБКА] ") + name + (f": {detail}" if detail else ""))

    record(sys.version_info >= (3, 10), "Версия Python", "установлена " + sys.version.split()[0] + "; необходима 3.10+")

    for name in ("app.py", "database.py", "launcher.py", "start.bat"):
        record((ROOT / name).is_file(), f"Файл {name}")

    try:
        import tkinter as tk
        root = tk.Tk()
        root.withdraw()
        root.update_idletasks()
        root.destroy()
        record(True, "Графическая библиотека Tkinter", f"Tk {tk.TkVersion}")
    except Exception as exc:
        record(False, "Графическая библиотека Tkinter", str(exc))

    try:
        from database import resolve_default_db_path
        db_file = resolve_default_db_path()
        record(True, "Расположение базы и права записи", str(db_file))
    except Exception as exc:
        record(False, "Расположение базы и права записи", str(exc))
        db_file = None

    if db_file is not None and db_file.exists():
        try:
            # Read-only opening does not modify the existing work database.
            connection = sqlite3.connect(db_file.as_uri() + "?mode=ro", uri=True, timeout=3)
            try:
                result = connection.execute("PRAGMA quick_check").fetchone()
                assert result is not None and result[0] == "ok", str(result)
            finally:
                connection.close()
            record(True, "Существующая база SQLite", "можно прочитать; quick_check = ok")
        except Exception as exc:
            record(False, "Существующая база SQLite", str(exc))
    elif db_file is not None:
        record(True, "База SQLite", f"появится после первого запуска: {db_file}")

    # Import the real application and create all of its widgets using a
    # disposable database. This catches startup failures that a plain Tk
    # import cannot detect, without reading or altering medical records.
    try:
        from database import Store
        from app import App
        with tempfile.TemporaryDirectory(prefix="azot_ui_check_") as tmp:
            temp_store = Store(Path(tmp) / "test.sqlite3")
            test_app = App(store=temp_store, start_hidden=True)
            try:
                test_app.withdraw()
                test_app.update_idletasks()
            finally:
                test_app.destroy()
        record(True, "Пробный запуск интерфейса", "окна и временная база создаются успешно")
    except Exception as exc:
        record(False, "Пробный запуск интерфейса", str(exc))

    status = "ПРОВЕРКА ПРОЙДЕНА" if good else "ОБНАРУЖЕНЫ ПРОБЛЕМЫ"
    lines.extend(["", status, "Если окно приложения не открывается, отправьте этот отчёт разработчику (без медицинских данных)."])
    report = "\n".join(lines) + "\n"
    print(report, flush=True)

    import os
    profile_root = Path(os.environ.get("LOCALAPPDATA") or tempfile.gettempdir())
    locations = (ROOT / "logs", profile_root / "AZOT_MedControl" / "logs",
                 Path(tempfile.gettempdir()) / "AZOT_MedControl" / "logs")
    saved = False
    for report_dir in locations:
        try:
            report_dir.mkdir(parents=True, exist_ok=True)
            report_file = report_dir / "diagnostics.txt"
            report_file.write_text(report, encoding="utf-8-sig")
            print("Диагностический файл:", report_file)
            saved = True
            break
        except OSError:
            continue
    if not saved:
        print("Не удалось сохранить диагностический файл ни в одной доступной папке.")
    return 0 if good else 1


if __name__ == "__main__":
    try:
        sys.exit(run_diagnostics())
    except Exception:
        traceback.print_exc()
        sys.exit(1)
