@echo off
setlocal EnableExtensions DisableDelayedExpansion
title AZOT MedControl - Python setup
echo This helper installs official Python 3.13 using winget.
echo It requires internet and installation permission on this PC.
echo No medical data is transmitted by this helper.
echo.
where winget >nul 2>&1
if errorlevel 1 goto without_winget
if /I "%~1"=="/called" goto install
choice /C YN /N /M "Install Python 3.13 for this Windows user? [Y/N] "
if errorlevel 2 exit /b 1
:install
winget install --id Python.Python.3.13 --exact --scope user --accept-source-agreements --accept-package-agreements
if errorlevel 1 goto failed
echo.
echo Python installer completed. Return to START_AZOT.bat.
exit /b 0
:without_winget
echo Windows Package Manager (winget) is unavailable or restricted.
echo Open https://www.python.org/downloads/windows/ and install Python 3.10+.
if /I not "%~1"=="/called" pause
exit /b 1
:failed
echo The Python installation was blocked or unsuccessful.
echo You can install Python from https://www.python.org/downloads/windows/.
if /I not "%~1"=="/called" pause
exit /b 1
