@echo off
setlocal EnableExtensions DisableDelayedExpansion
title AZOT MedControl - Windows
chcp 65001 >nul 2>&1
set "PYTHONUTF8=1"
set "PYTHONIOENCODING=utf-8"
set "APP_TARGET=launcher.py"
set "CHECK_MODE="
if /I "%~1"=="/check" set "CHECK_MODE=1"
if defined CHECK_MODE set "APP_TARGET=diagnose.py"

REM Always run from the program folder, not from the shortcut/desktop folder.
pushd "%~dp0" 2>nul
if errorlevel 1 goto folder_error
if not exist "launcher.py" goto missing_files
if not exist "app.py" goto missing_files
if not exist "database.py" goto missing_files
if not exist "diagnose.py" goto missing_files

REM The /check mode must work even when Tkinter is unavailable.
set "PROBE=import sys, sqlite3; assert sys.version_info >= (3, 10)"
if not defined CHECK_MODE set "PROBE=import sys, sqlite3, tkinter as t; assert sys.version_info >= (3, 10); w=t.Tk(); w.withdraw(); w.destroy()"

call :find_python
if defined AZOT_EXE goto launch

echo.
echo AZOT MedControl could not find a usable Python 3.10+ with Tkinter.
echo The program files are intact; Python is missing or Tk is broken.
if defined CHECK_MODE goto missing_python

if "%AZOT_SKIP_INSTALL%"=="1" goto missing_python
where winget >nul 2>&1
if errorlevel 1 goto missing_python
if not exist "INSTALL_PYTHON.bat" goto missing_python
echo.
echo Install official Python 3.13 through Windows Package Manager?
echo This requires internet. Windows may request permission.
echo Your employee and examination data will not be uploaded.
choice /C YN /N /M "Install Python now? [Y/N] "
if errorlevel 2 goto missing_python
call "%~dp0INSTALL_PYTHON.bat" /called
if errorlevel 1 goto missing_python
REM The current Command Prompt may have an old PATH. Search install folders again.
call :find_python
if defined AZOT_EXE goto launch
echo Python installation has finished but Python is not visible yet.
echo Close this window and double-click START_AZOT.bat again.
goto missing_python

:launch
echo.
echo AZOT MedControl - launching with "%AZOT_EXE%" %AZOT_ARGS%
"%AZOT_EXE%" %AZOT_ARGS% -u "%APP_TARGET%"
set "AZOT_EXIT_CODE=%errorlevel%"
if not "%AZOT_EXIT_CODE%"=="0" (
    echo.
    echo The application returned exit code %AZOT_EXIT_CODE%.
    echo Run CHECK_AZOT.bat to create a diagnostic report.
    echo Check logs\startup_errors.log or the folder in LOCALAPPDATA.
    pause
)
if defined CHECK_MODE if "%AZOT_EXIT_CODE%"=="0" pause
popd
exit /b %AZOT_EXIT_CODE%

:missing_python
call :write_no_python_report
echo.
echo Install Python from https://www.python.org/downloads/windows/
echo IMPORTANT: include "tcl/tk and IDLE" during installation.
echo Then double-click START_AZOT.bat again. No code changes are needed.
echo To troubleshoot, run CHECK_AZOT.bat.
pause
popd
exit /b 1

:missing_files
echo.
echo ERROR: One or more program files are missing.
echo Extract the entire ZIP to a normal folder before running START_AZOT.bat.
pause
popd
exit /b 1

:folder_error
echo.
echo ERROR: Cannot open the folder containing start.bat.
echo Move the extracted program folder to your Documents directory.
pause
exit /b 1

REM Python discovery. Each command is tested, not just located.
:find_python
set "AZOT_EXE="
set "AZOT_ARGS="
if defined AZOT_PYTHON call :probe "%AZOT_PYTHON%" ""
if defined AZOT_EXE exit /b 0
if exist ".venv\Scripts\python.exe" call :probe ".venv\Scripts\python.exe" ""
if defined AZOT_EXE exit /b 0
call :probe_on_path "py.exe" "-3"
if defined AZOT_EXE exit /b 0
REM Never launch the bare WindowsApps Python Store placeholder alias.
call :probe_on_path "python.exe" ""
if defined AZOT_EXE exit /b 0
call :probe_on_path "python3.exe" ""
if defined AZOT_EXE exit /b 0
REM Newer py may choose a broken version. Try other installed versions.
for %%V in (3.14 3.13 3.12 3.11 3.10) do (
    call :probe_on_path "py.exe" "-%%V"
    if defined AZOT_EXE exit /b 0
)
REM Python installed without Add to PATH or without the py launcher.
if defined LOCALAPPDATA (
    for /d %%P in ("%LOCALAPPDATA%\Programs\Python\Python3*" "%LOCALAPPDATA%\Programs\Python\PythonCore-3*") do (
        if exist "%%~fP\python.exe" call :probe "%%~fP\python.exe" ""
        if defined AZOT_EXE exit /b 0
    )
)
if defined ProgramFiles (
    for /d %%P in ("%ProgramFiles%\Python3*" "%ProgramFiles%\Python\Python3*") do (
        if exist "%%~fP\python.exe" call :probe "%%~fP\python.exe" ""
        if defined AZOT_EXE exit /b 0
    )
)
exit /b 0

:probe_on_path
REM Enumerate executables instead of launching a Windows Store placeholder.
REM Skip the WindowsApps execution alias; it may open the Store unexpectedly.
for /f "delims=" %%F in ('where.exe %~1 2^>nul') do (
    if /I not "%%~fF"=="%LOCALAPPDATA%\Microsoft\WindowsApps\%~1" (
        call :probe "%%~fF" "%~2"
        if defined AZOT_EXE exit /b 0
    )
)
exit /b 0

:probe
if "%~1"=="" exit /b 0
"%~1" %~2 -c "%PROBE%" >nul 2>&1
if not errorlevel 1 (
    set "AZOT_EXE=%~1"
    set "AZOT_ARGS=%~2"
)
exit /b 0

:write_no_python_report
if defined LOCALAPPDATA (
    set "AZOT_REPORT_DIR=%LOCALAPPDATA%\AZOT_MedControl\logs"
) else (
    set "AZOT_REPORT_DIR=%TEMP%\AZOT_MedControl\logs"
)
if not exist "%AZOT_REPORT_DIR%\" mkdir "%AZOT_REPORT_DIR%" >nul 2>&1
if exist "%AZOT_REPORT_DIR%\" (
    >"%AZOT_REPORT_DIR%\diagnostics.txt" echo ERROR: No compatible Python 3.10+ with working Tkinter was found.
    >>"%AZOT_REPORT_DIR%\diagnostics.txt" echo Date: %DATE% %TIME%
    >>"%AZOT_REPORT_DIR%\diagnostics.txt" echo Install Python from python.org with the tcl/tk and IDLE component.
    echo Diagnostic report: "%AZOT_REPORT_DIR%\diagnostics.txt"
) else (
    echo WARNING: Could not write a diagnostic file to "%AZOT_REPORT_DIR%".
)
exit /b 0
