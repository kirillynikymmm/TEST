"""Error handling tests for the Windows-compatible Python entry point."""
import io
import tempfile
import tkinter as tk
import unittest
from pathlib import Path
from unittest.mock import patch

import app
import launcher


class LauncherTests(unittest.TestCase):
    def test_success_exit(self):
        with patch.object(app, "main", return_value=None):
            self.assertEqual(launcher.run(), 0)

    def test_crash_writes_log_and_returns_error(self):
        with tempfile.TemporaryDirectory() as d:
            with patch.object(launcher, "ROOT", Path(d)), \
                 patch.object(app, "main", side_effect=RuntimeError("synthetic startup crash")), \
                 patch("tkinter.Tk", side_effect=tk.TclError("no display")), \
                 patch("sys.stderr", new_callable=io.StringIO):
                self.assertEqual(launcher.run(), 1)
            file = Path(d) / "logs" / "startup_errors.log"
            self.assertTrue(file.exists())
            self.assertIn("synthetic startup crash", file.read_text(encoding="utf-8"))


if __name__ == "__main__":
    unittest.main()
