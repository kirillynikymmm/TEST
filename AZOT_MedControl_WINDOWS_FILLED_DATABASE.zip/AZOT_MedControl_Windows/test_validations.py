"""Additional safety and reliability tests (run with unittest discover)."""
import sqlite3
import tempfile
import unittest
from datetime import date, datetime, timedelta
from pathlib import Path

from database import Store, now_iso, parse_float


class ValidationTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.path = Path(self.tmp.name) / "test.sqlite3"
        self.store = Store(self.path)
        self.eid = self.store.save_employee("AZ/456", "Петрова Марина", "15.04.1985", "Ж",
                                            department="Цех № 8", position="Оператор")

    def tearDown(self):
        self.tmp.cleanup()

    def details(self, **changes):
        data = dict(employee_id=self.eid, exam_type="Предсменный", shift_label="Дневная",
                    nurse_name="Иванова А.А.", complaints="Жалоб нет", complaint_tags=[],
                    visual_notes="Без особенностей", intoxication_signs=False,
                    alcohol_level=0, alcohol_unit="мг/л", alcohol_result="Отрицательный",
                    drug_result="Не требовалось", conclusion="Допущен",
                    non_admission_reason="", medical_comment="")
        data.update(changes)
        return data

    def reading(self, delta=0, **changes):
        stamp = (datetime.now().astimezone() + timedelta(minutes=delta)).isoformat(timespec="seconds")
        data = dict(measured_at=stamp, temperature=36.5, systolic=120, diastolic=78, pulse=78)
        data.update(changes)
        return data

    def test_nan_and_infinite_values_rejected(self):
        for val in ("nan", "NaN", "inf", "-inf"):
            with self.subTest(val=val), self.assertRaises(ValueError):
                parse_float(val, "Температура", 25, 50)
        with self.assertRaisesRegex(ValueError, "алкотеста"):
            self.store.create_exam(self.details(alcohol_level=float("nan")), [self.reading()])

    def test_measurement_validation_in_database(self):
        bad = [self.reading(systolic=70, diastolic=85),
               self.reading(pulse=-1), self.reading(temperature=None),
               self.reading(measured_at="invalid"), self.reading(systolic="120")]
        for measurement in bad:
            with self.subTest(measurement=measurement), self.assertRaises(ValueError):
                self.store.create_exam(self.details(), [measurement])
        self.assertEqual(len(self.store.list_exams()), 0)

    def test_out_of_interval_repeat_rejected(self):
        first = self.reading(delta=-15)
        with self.assertRaisesRegex(ValueError, "5–10"):
            self.store.create_exam(self.details(), [first, self.reading(delta=0)])
        first = self.reading(delta=-2)
        with self.assertRaisesRegex(ValueError, "5–10"):
            self.store.create_exam(self.details(), [first, self.reading(delta=0)])

    def test_timezone_required_and_future_rejected(self):
        future = self.reading(delta=10)
        with self.assertRaisesRegex(ValueError, "будущем"):
            self.store.create_exam(self.details(), [future])
        with self.assertRaisesRegex(ValueError, "часового пояса"):
            self.store.create_exam(self.details(), [self.reading(measured_at="2026-10-15T14:00:00")])

    def test_conflicting_decision_rejected_in_store(self):
        with self.assertRaisesRegex(ValueError, "конфликтуют"):
            self.store.create_exam(self.details(alcohol_result="Положительный"), [self.reading()])
        with self.assertRaisesRegex(ValueError, "причину"):
            self.store.create_exam(self.details(conclusion="Не допущен"), [self.reading()])
        with self.assertRaisesRegex(ValueError, "жалоб"):
            self.store.create_exam(self.details(complaints=""), [self.reading()])
        with self.assertRaisesRegex(ValueError, "исследования мочи"):
            self.store.create_exam(self.details(intoxication_signs=True), [self.reading()])
        self.assertEqual(len(self.store.list_exams()), 0)

    def test_escaped_search_and_period(self):
        exam_id = self.store.create_exam(self.details(), [self.reading()])
        self.assertEqual(self.store.list_exams("Оператор")[0]["id"], exam_id)
        self.assertEqual(self.store.list_exams("Цех № 8")[0]["id"], exam_id)
        self.assertEqual(self.store.list_exams("%")[0:1], [])
        self.assertEqual(self.store.list_exams("_")[0:1], [])
        self.assertEqual(len(self.store.list_exams(period="Сегодня")), 1)
        self.assertEqual(len(self.store.list_exams(period="7 дней")), 1)
        self.assertEqual(self.store.employee_exams(self.eid)[0]["id"], exam_id)
        self.assertEqual(len(self.store.same_day_exams(self.eid, "Предсменный", date.today().isoformat())), 1)

    def test_date_filter_skips_old_exam(self):
        self.store.create_exam(self.details(), [self.reading(delta=-11*24*60)])
        self.store.create_exam(self.details(), [self.reading()])
        self.assertEqual(len(self.store.list_exams(period="Сегодня")), 1)
        self.assertEqual(len(self.store.list_exams(period="7 дней")), 1)
        self.assertEqual(len(self.store.list_exams(period="Все")), 2)

    def test_backup_and_integrity_check(self):
        self.store.create_exam(self.details(), [self.reading()])
        ok, msg = self.store.check_integrity()
        self.assertTrue(ok, msg)
        target = Path(self.tmp.name) / "nested" / "copy.sqlite3"
        self.store.backup(target)
        self.assertEqual(len(Store(target).list_exams()), 1)
        with self.assertRaisesRegex(ValueError, "совпадать"):
            self.store.backup(self.path)

    def test_employee_missing_and_long_fio(self):
        with self.assertRaisesRegex(ValueError, "не найдена"):
            self.store.save_employee("x", "Nonexistent", "01.01.1988", "М", employee_id=999999)
        with self.assertRaisesRegex(ValueError, "слишком длинные"):
            self.store.save_employee("x", "а" * 181, "01.01.1988", "М")


if __name__ == "__main__":
    unittest.main()
