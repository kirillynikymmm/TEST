"""Additional bug regressions for Windows reliability improvements in v4.2."""
from __future__ import annotations

import tempfile
import tkinter as tk
import unittest
from pathlib import Path
from unittest.mock import patch

import launcher
from app import App, EmployeeDialog
from database import Store, now_iso, parse_int


class InputAndStartupTests(unittest.TestCase):
    def test_int_parser_rejects_non_ascii_and_oversized_pastes(self):
        for bad in ("²", "٣", "9" * 6000):
            with self.subTest(value=bad[:10]), self.assertRaisesRegex(ValueError, "целое число"):
                parse_int(bad, "Пульс", 15, 300)
        self.assertEqual(parse_int(" 80 ", "Пульс", 15, 300), 80)

    def test_readonly_folder_startup_log_falls_back_to_temp(self):
        with tempfile.TemporaryDirectory() as directory:
            tmp = Path(directory)
            # A regular file cannot be used as a parent for ROOT/logs/...
            occupied = tmp / "cannot-be-a-directory"
            occupied.write_text("x")
            with patch.object(launcher, "ROOT", occupied), patch.object(
                launcher.tempfile, "gettempdir", return_value=directory
            ):
                try:
                    raise RuntimeError("test startup failure")
                except RuntimeError:
                    path = launcher.log_startup_error()
            self.assertEqual(path, tmp / "AZOT_MedControl" / "startup_errors.log")
            self.assertIn("test startup failure", path.read_text(encoding="utf-8"))

    def test_windows_check_does_not_require_tk_to_run_diagnosis(self):
        batch = (Path(__file__).parent / "start.bat").read_text(encoding="utf-8")
        self.assertIn('if /I "%~1"=="/check" set "CHECK_MODE=1"', batch)
        self.assertIn('if defined CHECK_MODE set "APP_TARGET=diagnose.py"', batch)
        self.assertIn('set "PROBE=import sys, sqlite3;', batch)
        self.assertIn('if not defined CHECK_MODE set "PROBE=import sys, sqlite3, tkinter as t;', batch)
        self.assertIn('setlocal EnableExtensions DisableDelayedExpansion', batch)


class GUISafetyTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.store = Store(Path(self.temp.name) / "testing.sqlite3")
        self.employee_id = self.store.save_employee("T-900", "Иванов Иван Тестовый", "01.06.1994", "М")
        try:
            self.app = App(self.store)
            self.app.withdraw()
        except tk.TclError as exc:
            self.temp.cleanup()
            self.skipTest(f"No Tk display: {exc}")

    def tearDown(self):
        if hasattr(self, "app"):
            self.app.destroy()
        self.temp.cleanup()

    def enter_exam(self):
        self.app.employee_choice.set(next(iter(self.app.employee_lookup)))
        self.app.on_employee_selected()
        self.app.nurse_name.set("Сидорова Н. А.")
        self.app.temp_input.set("36.5")
        self.app.sys_input.set("120")
        self.app.dia_input.set("80")
        self.app.pulse_input.set("72")
        self.app.add_reading()
        self.app.set_no_complaints()
        self.app.set_normal_visual()
        self.app.intoxication_assessment.set("Не выявлены")
        self.app.alcohol_level.set("0")
        self.app.alcohol_result.set("Отрицательный")
        self.app.conclusion.set("Допущен")
        self.app.acknowledged.set(True)
        with patch.object(self.app, "open_exam_details"):
            self.app.save_exam()

    def test_form_warns_when_only_nurse_or_dropdown_was_changed(self):
        self.assertFalse(self.app.has_unsaved_form())
        self.app.nurse_name.set("Новое ФИО")
        self.assertTrue(self.app.has_unsaved_form())
        self.app.reset_form(keep_nurse=True)
        self.assertFalse(self.app.has_unsaved_form())
        for field, new_value in (
            (self.app.exam_type, "Предрейсовый"),
            (self.app.shift_label, "Ночная"),
            (self.app.intoxication_assessment, "Не выявлены"),
            (self.app.drug_result, "Отрицательный"),
        ):
            with self.subTest(field=repr(field)):
                field.set(new_value)
                self.assertTrue(self.app.has_unsaved_form())
                self.app.reset_form(keep_nurse=True)
                self.assertFalse(self.app.has_unsaved_form())

    def test_employee_dialog_scrolls_when_screen_height_is_constrained(self):
        previous_scale = float(self.app.tk.call("tk", "scaling"))
        try:
            self.app.tk.call("tk", "scaling", 2.0)
            with patch.object(EmployeeDialog, "winfo_screenheight", return_value=560):
                dialog = EmployeeDialog(self.app)
            try:
                dialog.update_idletasks()
                before = dialog.dialog_canvas.yview()
                self.assertLess(before[1], 1.0)
                dialog.dialog_canvas.yview_moveto(1.0)
                dialog.update_idletasks()
                self.assertAlmostEqual(dialog.dialog_canvas.yview()[1], 1.0)
            finally:
                dialog.destroy()
        finally:
            self.app.tk.call("tk", "scaling", previous_scale)

    def test_csv_write_failure_keeps_existing_file(self):
        self.enter_exam()
        export = Path(self.temp.name) / "report.csv"
        export.write_bytes(b"previous report stays intact")
        with patch("app.messagebox.askyesno", return_value=True), patch(
                "app.filedialog.asksaveasfilename", return_value=str(export)), patch(
                "app.os.replace", side_effect=OSError("file is locked")), patch(
                "app.messagebox.showerror") as error:
            self.app.export_csv()
        self.assertIn("file is locked", error.call_args.args[1])
        self.assertEqual(export.read_bytes(), b"previous report stays intact")
        self.assertEqual(list(Path(self.temp.name).glob(".azot_export_*")), [])

    def test_csv_export_succeeds_with_utf8_bom_and_semicolon(self):
        self.enter_exam()
        export = Path(self.temp.name) / "report.csv"
        with patch("app.messagebox.askyesno", return_value=True), patch(
                "app.filedialog.asksaveasfilename", return_value=str(export)), patch(
                "app.messagebox.showinfo"):
            self.app.export_csv()
        blob = export.read_bytes()
        self.assertTrue(blob.startswith(b"\xef\xbb\xbf"))
        decoded = blob.decode("utf-8-sig")
        self.assertIn("Иванов Иван Тестовый", decoded)
        self.assertIn("Дата/время;", decoded)


if __name__ == "__main__":
    unittest.main()
