"""Regression tests for v4.4 — missing data, scroll and Windows startup guard."""
from __future__ import annotations

import tempfile
import tkinter as tk
import unittest
from datetime import datetime, timedelta
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from app import App
from database import Store


class StoreV44Tests(unittest.TestCase):
    def setUp(self):
        self.folder = tempfile.TemporaryDirectory()
        self.store = Store(Path(self.folder.name) / "v44.sqlite3")
        self.id = self.store.save_employee("44", "Тестовый Сотрудник", "07.06.1990", "М")

    def tearDown(self):
        self.folder.cleanup()

    def make_details(self):
        return dict(employee_id=self.id, exam_type="Предсменный", nurse_name="Медсестра Тестовая",
                    complaints="Жалоб нет", visual_notes="Без особенностей", intoxication_signs=False,
                    alcohol_level=0, alcohol_unit="мг/л", alcohol_result="Отрицательный",
                    drug_result="Не требовалось", conclusion="Допущен")

    def make_reading(self, mins_back=0, **kw):
        data = dict(measured_at=(datetime.now().astimezone() - timedelta(minutes=mins_back)).isoformat(timespec="seconds"),
                    systolic=120, diastolic=80, pulse=76, temperature=36.6)
        data.update(kw)
        return data

    def test_repeated_measurement_without_optional_temperature_is_saved(self):
        repeat = self.make_reading(0)
        del repeat["temperature"]
        exam_id = self.store.create_exam(self.make_details(), [self.make_reading(6), repeat])
        _, attempts = self.store.get_exam(exam_id)
        self.assertEqual(len(attempts), 2)
        self.assertIsNone(attempts[1]["temperature"])

    def test_primary_measurement_without_temperature_shows_validation_error(self):
        primary = self.make_reading()
        del primary["temperature"]
        with self.assertRaisesRegex(ValueError, "температуру"):
            self.store.create_exam(self.make_details(), [primary])

    def test_omitted_optional_text_fields_are_saved_empty(self):
        exam_id = self.store.create_exam(self.make_details(), [self.make_reading()])
        exam, _ = self.store.get_exam(exam_id)
        self.assertEqual(exam["non_admission_reason"], "")
        self.assertEqual(exam["medical_comment"], "")

    def test_nurse_and_notes_are_trimmed(self):
        detail = self.make_details()
        detail.update(nurse_name="   Медсестра     Тестовая   ", complaints="  Жалоб нет  ")
        exam_id = self.store.create_exam(detail, [self.make_reading()])
        exam, _ = self.store.get_exam(exam_id)
        self.assertEqual(exam["nurse_name"], "Медсестра Тестовая")
        self.assertEqual(exam["complaints"], "Жалоб нет")

    def test_missing_or_nontext_medical_fields_return_valueerror(self):
        for bad_key, bad_value in (("nurse_name", None), ("complaints", None),
                                   ("visual_notes", None), ("medical_comment", None),
                                   ("non_admission_reason", None)):
            with self.subTest(field=bad_key):
                data = self.make_details()
                data[bad_key] = bad_value
                with self.assertRaises(ValueError):
                    self.store.create_exam(data, [self.make_reading()])
        self.assertEqual(self.store.list_exams(), [])


class UIV44Tests(unittest.TestCase):
    def setUp(self):
        self.folder = tempfile.TemporaryDirectory()
        try:
            self.app = App(store=Store(Path(self.folder.name) / "gui.sqlite3"))
        except tk.TclError as err:
            self.folder.cleanup()
            self.skipTest("No GUI display: " + str(err))
        self.app.update_idletasks()

    def tearDown(self):
        if hasattr(self, "app"):
            self.app.destroy()
        self.folder.cleanup()

    def test_overview_and_about_mousewheel_scrolls(self):
        for page, canvas in (("overview", self.app.overview_canvas),
                             ("about", self.app.about_canvas)):
            with self.subTest(page=page):
                self.app.navigate(page)
                self.app.update_idletasks()
                canvas.yview_moveto(0)
                self.app._on_exam_wheel(SimpleNamespace(widget=self.app.header_title,
                                                         delta=-120, num=None))
                if canvas.yview()[1] < 1:
                    self.assertGreater(canvas.yview()[0], 0)

    def test_small_logical_screen_is_not_exceeded(self):
        with patch.object(App, "winfo_screenwidth", return_value=800), patch.object(
            App, "winfo_screenheight", return_value=480
        ):
            another = App(store=Store(Path(self.folder.name) / "small.sqlite3"), start_hidden=True)
        try:
            dims = another.geometry().split("+")[0]
            width, height = map(int, dims.split("x"))
            self.assertLessEqual(width, 800)
            self.assertLessEqual(height, 480)
        finally:
            another.destroy()

    def test_batch_has_missing_python_diagnostic(self):
        bat = (Path(__file__).resolve().parent / "start.bat").read_text(encoding="utf-8")
        self.assertIn('diagnostics.txt', bat)
        self.assertIn('setlocal EnableExtensions DisableDelayedExpansion', bat)
        self.assertIn('pushd "%~dp0"', bat)


if __name__ == "__main__":
    unittest.main()
