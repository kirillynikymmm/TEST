"""Reliable Windows entry point: display startup errors and write a local log.

The launcher intentionally does not transmit any data or install dependencies.
"""
from __future__ import annotations

import sys
import os
import tempfile
import traceback
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def log_startup_error() -> Path | None:
    localappdata = os.environ.get("LOCALAPPDATA")
    candidates = [ROOT / "logs" / "startup_errors.log"]
    if localappdata:
        candidates.append(Path(localappdata) / "AZOT_MedControl" / "logs" / "startup_errors.log")
    candidates.append(Path(tempfile.gettempdir()) / "AZOT_MedControl" / "startup_errors.log")
    for log_path in candidates:
        try:
            log_path.parent.mkdir(parents=True, exist_ok=True)
            with log_path.open("a", encoding="utf-8") as out:
                out.write(f"\n----- {datetime.now().astimezone().isoformat(timespec='seconds')} -----\n")
                out.write(traceback.format_exc())
            return log_path
        except OSError:
            continue
    return None


def run() -> int:
    try:
        from app import main
        main()
        return 0
    except Exception as error:
        log_path = log_startup_error()
        print("Ошибка запуска АЗОТ Медконтроль:", error, file=sys.stderr)
        if log_path:
            print("Журнал ошибки:", log_path, file=sys.stderr)
        try:
            import tkinter as tk
            from tkinter import messagebox
            popup = tk.Tk()
            popup.withdraw()
            messagebox.showerror(
                "АЗОТ Медконтроль — ошибка запуска",
                "Не удалось запустить программу.\n\n"
                + str(error)
                + ("\n\nПодробности: " + str(log_path) if log_path else
                   "\n\nНе удалось создать журнал ошибки."),
                parent=popup,
            )
            popup.destroy()
        except Exception:
            pass
        return 1


if __name__ == "__main__":
    sys.exit(run())
