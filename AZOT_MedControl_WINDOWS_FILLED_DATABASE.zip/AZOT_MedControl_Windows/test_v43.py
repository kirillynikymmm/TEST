"""Regression tests for Windows startup, user-data fallback and GUI edge cases."""
from __future__ import annotations

import tempfile
import tkinter as tk
import unittest
from pathlib import Path
from unittest.mock import patch

import database
from database import Store
from app import App, EmployeeDialog


class WritableDataTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        root = Path(self.tmp.name)
        self.local = root / "app" / "data" / "medcontrol.sqlite3"
        self.profile = root / "User profile" / "AZOT_MedControl" / "data" / "medcontrol.sqlite3"

    def tearDown(self):
        self.tmp.cleanup()

    def patch_paths(self):
        from contextlib import ExitStack
        stack = ExitStack()
        stack.enter_context(patch.object(database, "DB_PATH", self.local))
        stack.enter_context(patch.object(database, "user_profile_db_path", return_value=self.profile))
        return stack

    def test_existing_local_database_is_never_hidden_by_profile_copy(self):
        local_store = Store(self.local)
        local_store.save_employee("11", "Сотрудник Основной", "01.01.1990", "М")
        profile_store = Store(self.profile)
        profile_store.save_employee("12", "Сотрудник Профиль", "01.01.1990", "М")
        with self.patch_paths():
            actual = Store()
        self.assertEqual(actual.db_path, self.local)
        self.assertEqual(actual.list_employees()[0]["personnel_number"], "11")

    def test_profile_database_reused_across_program_updates(self):
        profile_store = Store(self.profile)
        profile_store.save_employee("12", "Профильный Сотрудник", "01.01.1990", "М")
        with self.patch_paths():
            actual = Store()
        self.assertEqual(actual.db_path, self.profile)
        self.assertEqual(len(actual.list_employees()), 1)
        self.assertFalse(self.local.exists())

    def test_profile_fallback_when_program_folder_is_not_writable(self):
        probe = database.verify_folder_writable

        def restricted(path):
            if path == self.local.parent:
                raise PermissionError("simulated Windows protected folder")
            return probe(path)

        with self.patch_paths(), patch.object(database, "verify_folder_writable", side_effect=restricted):
            actual = Store()
        self.assertEqual(actual.db_path, self.profile)
        self.assertTrue(self.profile.exists())

    def test_existing_locked_database_is_not_replaced_by_empty_profile(self):
        Store(self.local)
        probe = database.verify_folder_writable

        def restricted(path):
            if path == self.local.parent:
                raise PermissionError("read-only")
            return probe(path)

        with self.patch_paths(), patch.object(database, "verify_folder_writable", side_effect=restricted):
            with self.assertRaisesRegex(PermissionError, "Не создаём вместо неё пустую базу"):
                Store()
        self.assertFalse(self.profile.exists())

    def test_directory_obstructing_database_path_is_not_overwritten(self):
        self.local.mkdir(parents=True)
        with self.patch_paths():
            with self.assertRaisesRegex(PermissionError, "занят папкой"):
                Store()


class WindowTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.store = Store(Path(self.tmp.name) / "db.sqlite3")
        try:
            self.app = App(store=self.store, start_hidden=True)
        except tk.TclError as exc:
            self.tmp.cleanup()
            self.skipTest(f"Display not available: {exc}")

    def tearDown(self):
        if hasattr(self, "app"):
            self.app.destroy()
        self.tmp.cleanup()

    def test_employee_dialog_warns_about_unsaved_changes(self):
        dialog = EmployeeDialog(self.app)
        dialog.full_name.set("Не сохранено")
        with patch("app.messagebox.askyesno", return_value=False) as warn:
            dialog.cancel()
            warn.assert_called_once()
            self.assertTrue(dialog.winfo_exists())
        with patch("app.messagebox.askyesno", return_value=True):
            dialog.cancel()
        self.assertFalse(dialog.winfo_exists())

    def test_small_screen_employee_dialog_shrinks_width(self):
        with patch.object(EmployeeDialog, "winfo_screenwidth", return_value=540):
            dialog = EmployeeDialog(self.app)
        try:
            self.app.update_idletasks()
            self.assertLessEqual(dialog.winfo_width(), 540)
        finally:
            dialog.destroy()

    def test_about_page_scrollable_at_low_resolution(self):
        self.app.deiconify()
        self.app.geometry("810x550")
        self.app.navigate("about")
        self.app.update_idletasks()
        before = self.app.about_canvas.yview()
        self.assertLess(before[1], 1.0)
        self.app.about_canvas.yview_moveto(1.0)
        self.app.update_idletasks()
        self.assertAlmostEqual(self.app.about_canvas.yview()[1], 1.0)

    def test_profile_data_exports_and_backups_follow_profile(self):
        profile = Path(self.tmp.name) / "AppData" / "AZOT_MedControl" / "data" / "medcontrol.sqlite3"
        self.app.store.db_path = profile
        with patch("app.user_profile_db_path", return_value=profile):
            self.assertEqual(self.app._output_dir("exports"), profile.parent.parent / "exports")
            self.assertEqual(self.app._output_dir("backups"), profile.parent.parent / "backups")

    def test_runtime_exception_uses_temp_folder_if_log_not_writable(self):
        collision = Path(self.tmp.name) / "blocked-parent"
        collision.write_text("not a directory", encoding="utf-8")
        with patch.object(self.app, "_output_dir", return_value=collision), patch(
            "app.tempfile.gettempdir", return_value=self.tmp.name
        ), patch("app.messagebox.showerror") as popup:
            try:
                raise RuntimeError("fault to be captured")
            except RuntimeError as exc:
                self.app.report_callback_exception(type(exc), exc, exc.__traceback__)
        logfile = Path(self.tmp.name) / "AZOT_MedControl" / "runtime_errors.log"
        self.assertIn("fault to be captured", logfile.read_text(encoding="utf-8"))
        self.assertIn(str(logfile), popup.call_args.args[1])


if __name__ == "__main__":
    unittest.main()
