@echo off
setlocal EnableExtensions DisableDelayedExpansion
if not exist "%~dp0AZOT_MedControl_Windows\check_windows.bat" goto missing
call "%~dp0AZOT_MedControl_Windows\check_windows.bat"
exit /b %errorlevel%
:missing
echo ERROR: Please extract the whole ZIP before running this BAT.
pause
exit /b 1
